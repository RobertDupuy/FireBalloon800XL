# Fireballoon — Atari 800XL playtest release 0.3

**Fireballoon, created by Mark2006.**

This is continued development of the original Atari demo as a native 6502 game. The source was rebuilt after the original source was lost, using the supplied screen recording as the visual reference.

## Faster fires, continuing outbreaks, and new controls

This revision replaces a single opening arrangement with sustained outbreaks. Each call starts with four or five small fires, then introduces 10–30 more at intervals that become shorter later in the campaign. The upper HUD's `NEXT` counter shows outbreaks still to come. A call clears only when all fires, rescues, and pending outbreaks are finished.

New outbreaks wait while the building is at that call's fire limit, from five to eight simultaneous fires. The waiting outbreak is preserved, so clearing the first group cannot skip the rest of the call. From call 16, every fourth outbreak starts at stage two; other outbreaks begin at stage one. Neighbor-to-neighbor spreading adds further pressure from call 5 onward.

**Tap and release FIRE to throw. Hold FIRE for one second to refill.** You can top up a partially filled bucket whenever you choose, without emptying it first. The bucket holds eight balloons. The upper HUD shows an eight-segment water gauge marked `W`; while FIRE is held it becomes a refill-progress bar marked `R`. When the bar fills, the bucket is full. Releasing a completed hold does not throw an extra balloon. A shorter press is a throw command.

LEFT/RIGHT movement remains available while charging the refill. The countdown, fire growth, outbreaks, wind, and falling bricks continue, so keep moving when necessary. DOWN is no longer a refill control.

Masonry falls from the first call. From call 9 some bricks start above your current position and fall faster; they keep their horizontal position after release. From call 15 they fall faster again. Neighbor spread accelerates from one event every six seconds to one every three seconds. It ignites an empty window beside a burning window on the same floor when space is available; occupied resident windows are protected until rescued.

## Fire growth and building collapse

Fires visibly grow every **four seconds on calls 1–4, three seconds on calls 5–12, and two seconds on calls 13–20**. They have four distinct flame heights: 4, 8, 12, and 14 pixels, all rising from the same fixed window sill. The frame stays in exactly the same place for empty windows, residents, and every animated fire stage.

A water-balloon hit shrinks the fire by one stage and resets its growth age. Hitting a stage-one fire extinguishes it. Stage four pulses the upper HUD and sounds an alarm. If any stage-four fire survives one further growth interval, the building flares up and collapses into rubble, costing one life.

An untouched stage-one fire can therefore destroy the building after 16 seconds in call 1 or eight seconds in call 20. A stage-two outbreak has less time left. Cooling a fire buys time as well as reducing its strength, so urgent fires may need a hit before you can finish extinguishing another window.

The bottom of the gameplay screen contains no text. Pause, completion, failure, and building-loss messages appear in the upper HUD.

## Run

Load `FIREBALLOON.xex` as an executable in an Atari emulator or through an Atari executable loader/cartridge menu. Use an Atari 800XL with 64 KB RAM, BASIC disabled, and joystick port 1. Both NTSC and PAL are supported. Emulator testing uses Atari800 with its built-in Altirra replacement OS. Real Atari hardware has not yet been tested.

If an emulator asks about BASIC, turn it off. On hardware, follow your loader's normal BASIC-disable procedure, often holding OPTION while booting. Reset returns control to the machine/loader; reload the XEX to start again.

## Controls

- Joystick LEFT/RIGHT: move along the street, including while refilling.
- Tap and release FIRE: queue one balloon throw, if water remains.
- Hold FIRE for one full second: refill the bucket to eight balloons.
- FIRE or START: begin from the title and continue past a dispatch briefing.
- SELECT: pause/resume, including an unfinished refill.

A short press is released before the refill bar completes; the balloon then leaves the hand after the pickup animation. A full hold refills once and produces no throw on release. Holding with an already-full bucket does not spend water. Dispatch screens briefly ignore presses during transitions, and the press used to enter a call is consumed rather than firing a balloon.

## Rules and tactics

Finish every scheduled outbreak, extinguish every burning window, and rescue every visible person before the countdown expires. Aim a water balloon at a person's window to rescue them. Ordinary blue windows are already safe. The HUD shows active fires (`F`), people (`P`), the water/refill bar, wind direction, and pending outbreaks (`NEXT`).

Balloons travel upward, drift with the wind, and stop at the first live target they strike. A lower fire can intercept a balloon intended for an upper fire in the same column. At most five balloons can be in flight. A balloon uses one unit of water when it leaves the hand; starting the pickup animation does not use water.

Watch the critical fires rather than simply sweeping from one side to the other. Clear lower obstructions to reach urgent upper windows. Refill while moving away from falling masonry, and top up during a quiet moment instead of waiting for an empty bucket. Cleared windows can catch fire again if their neighbor is still burning.

The game starts with three lives. Timeout, a collision with falling masonry, or a building burning down costs one life and restarts the current call after a briefing. You briefly blink while protected at the start of a call. Score is retained when retrying a call. Three failures end the game. Completing all 20 calls reaches the ending.

## Score

- Weakening a fire: 20 points.
- Extinguishing a fire: 100 points, plus a consecutive-extinguish bonus of 10–90 points.
- Rescuing a person: 250 points.
- Completing a call: 10 points per second remaining.

A balloon that leaves the top without a hit breaks the extinguish streak. Score saturates at 999990. There is no persistent high-score save in this release.

## Twenty calls

Every opening fire begins at stage one. `Outbreaks` counts scheduled new fires in addition to the opening fires; neighbor spread can add more. The interval is the minimum gap between scheduled outbreaks, which wait when the active-fire cap is reached. All times below are simulation seconds on both PAL and NTSC.

| Call | Name | Time | Growth | Opening fires | Outbreaks | Interval | Fire cap | Rescues |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | First Response | 30 s | 4 s | 4 | 10 | 2 s | 5 | 0 |
| 2 | Upper Floors | 32 s | 4 s | 4 | 12 | 1.9 s | 5 | 1 |
| 3 | Block Party | 34 s | 4 s | 4 | 13 | 1.8 s | 5 | 1 |
| 4 | Hot Spots | 36 s | 4 s | 4 | 14 | 1.7 s | 6 | 1 |
| 5 | Call For Help | 38 s | 3 s | 4 | 15 | 1.6 s | 6 | 2 |
| 6 | East Wind | 40 s | 3 s | 4 | 16 | 1.5 s | 6 | 2 |
| 7 | West Wind | 40 s | 3 s | 4 | 17 | 1.5 s | 6 | 2 |
| 8 | Stubborn Flames | 42 s | 3 s | 4 | 18 | 1.4 s | 6 | 2 |
| 9 | Falling Masonry | 42 s | 3 s | 4 | 19 | 1.4 s | 6 | 2 |
| 10 | Crosswinds | 44 s | 3 s | 4 | 20 | 1.3 s | 6 | 2 |
| 11 | Firebreak | 44 s | 3 s | 5 | 21 | 1.3 s | 7 | 2 |
| 12 | Rooftop Rescue | 46 s | 3 s | 5 | 22 | 1.2 s | 7 | 3 |
| 13 | Gust Front | 46 s | 2 s | 5 | 23 | 1.2 s | 7 | 2 |
| 14 | Old Warehouse | 48 s | 2 s | 5 | 24 | 1.2 s | 7 | 2 |
| 15 | Night Watch | 48 s | 2 s | 5 | 25 | 1.1 s | 7 | 3 |
| 16 | The Fire Spreads | 50 s | 2 s | 5 | 26 | 1.1 s | 7 | 3 |
| 17 | High Alert | 50 s | 2 s | 5 | 27 | 1.1 s | 8 | 3 |
| 18 | Inferno | 52 s | 2 s | 5 | 28 | 1 s | 8 | 3 |
| 19 | Last Call | 52 s | 2 s | 5 | 29 | 1 s | 8 | 3 |
| 20 | Save The Block | 55 s | 2 s | 5 | 30 | 0.9 s | 8 | 4 |

Calls 1–5 use a broad apartment, 6–10 a narrower tower, 11–15 two connected wings, and 16–20 a dark final block. Opening layouts are fixed per call; later outbreaks find free windows as play develops. East/west wind begins on calls 6/7, and changing gusts appear in later calls.

## Graphics and timing

White street markings, dark-blue balloons, and a scanline-colored character with a red/white cap and striped shirt, skin tones, and blue trousers retain the visual direction of the demo. Four poses show the hand reaching into the bucket, lifting a balloon, and releasing it overhead.

- A graphical ANTIC 4 title screen presents the Fireballoon wordmark, scene artwork, controls, and `Created by Mark2006` credit. It runs on the Atari as native character graphics.
- Custom ANTIC 4 graphics draw the scene, windows, people, and animated fires. Inverse characters supply the fifth color. Window frames and sills remain aligned across every state.
- ANTIC 2 draws the upper HUD, briefings, and ending.
- Display-list interrupts change color registers and character sets by screen band. The character's costume uses unrolled scanline changes.
- Player 0 draws the main character; player 1 is reused for five water balloons; player 2 draws masonry; player 3 draws the bucket.
- Window updates are staged for VBI transfer. Double-buffered player/missile memory and balloon position tables avoid clearing sprites while ANTIC reads them.
- POKEY effects cover throws, hits, rescues, refills, low time, critical fires, and failure. There is no music.
- Gameplay uses 50 updates per nominal second on both standards; NTSC display remains 60 Hz and PAL 50 Hz. Actual hardware refresh rates differ slightly from these nominal values.

## Build the XEX

Install Python 3 with Pillow and the cc65 toolchain (`ca65` and `ld65`). From this directory:

```sh
python3 tools/build.py
```

If the assembler binaries are not on PATH, set `CC65_BIN` to their directory. The build regenerates graphics and level data, then writes `build/FIREBALLOON.xex`. No Atari ROM or emulator is needed to build. No copyrighted OS ROMs are included.

The memory map reserves code at $2000, variables at $5000, screen at $6000, character sets at $6400/$6800, display list at $6C00, double-buffered PM memory at $7000/$7800, and initial assets at $8000.

## Validation and playtesting

This is an intentionally harder playtest revision. **Completion of all 20 calls has not been verified for release 0.3.** Full-campaign results from release 0.2 do not apply to the new two-second late-game growth and continuing outbreaks.

The current action and growth checks pass on PAL and NTSC. `tests/action_regression.py` checks the native graphical title, charset restoration, tap-to-throw, partial-bucket top-up, refill progress, full-hold release behavior, movement during refill, continued hazards, pause, outbreak capacity, and the complete-clear condition. It also measures actual growth and collapse timing. `tests/growth_regression.py` covers all four stages, water cooling, last-tick saves, collapse, retry/game over, and the blank lower screen. These targeted tests deliberately set some state to reach edge cases quickly.

`tests/window_art_regression.py` checks the common frame and sill and the distinct flame heights across animation frames and window states. This is separate from controller playtesting.

Balance probes select a call in its briefing and then use joystick input during play. Their controller reads game memory to aim and predict hazards. Current probes can clear early calls but lose buildings on harder calls, including calls 15 and 20. These failures show that the present automated policy does not solve those calls; they establish neither impossibility nor fair human difficulty. Balance and action reports include the executable checksum to identify the exact build tested. Reports from earlier builds are historical, not evidence for this executable.

The C harness uses the libatari800 API. To rerun it, build libatari800, compile `tests/emulator.c` against that library and libm into `build/emulator`, and run the Python test scripts. The optional no-op `hg_*` functions support hooks in the emulator build used for this release; they are not part of the game.

The 40.6-second MP4 preview contains native NTSC emulator output and actual POKEY audio at normal speed. It shows the graphical title and the first call, then selects call 20 during the level transition to demonstrate late-game fire growth and collapse. Fires, timers, lives, water, and hazards are not altered during active play. This is a feature demonstration, not a completed campaign.

To regenerate the video, install Pillow and NumPy for Python and put FFmpeg on PATH, then run `python3 tests/video_preview.py` with the emulator harness built. NumPy and FFmpeg are preview-generation dependencies; building the XEX itself needs only Python, Pillow, and cc65.

Real hardware behavior and human difficulty still need playtesting. The native source and executable are included so those results can guide further revisions.
