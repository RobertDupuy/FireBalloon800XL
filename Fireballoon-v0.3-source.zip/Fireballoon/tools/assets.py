from pathlib import Path
P=Path(__file__).resolve().parents[1]/'src'
# Original pixel art, reconstructed from the user's video reference.
tiles=[bytes(8)]*128
def tile(i,rows):
    tiles[i]=bytes(sum(int(v)<<(6-2*x) for x,v in enumerate(row)) for row in rows)
tile(1,['1111']*8) # facade
tile(2,['2222','2222','1111','1111','1111','1111','1111','1111'])
# Every window state shares this exact frame and sill. ANTIC inverse changes
# code 3 alone, so code 2 keeps the frame the same color before/after a hit.
def window_frame(fill=0):
    return [[2 if y in (0,15) or x in (0,7) else fill
             for x in range(8)] for y in range(16)]
def window_tiles(base,pixels):
    for q in range(4):
        tile(base+q,[''.join(map(str,row[(q%2)*4:(q%2)*4+4]))
                     for row in pixels[(q//2)*8:(q//2)*8+8]])
empty_window=window_frame(3)
for y in (2,3,4): empty_window[y][1]=0
window_tiles(3,empty_window)
tile(7,['2222','3333','3330','3303','3033','0333','2222','0000']) # pavement
tile(8,['0000','0000','1111','1111','0000','0000','0000','0000'])
tile(9,['1111','1222','1232','1222','1222','1232','1222','1222'])
tile(10,['1111','2221','2321','2221','2221','2321','2221','2221'])
tile(11,['1222']*8); tile(12,['2221']*8)
# cloud pieces
for i,rows in enumerate([['0000','0000','0000','0033','0333','3333','0333','0000'],['0000','0003','0033','3333','3333','3333','3333','0000'],['0000','0000','3000','3300','3333','3333','3330','0000']]): tile(13+i,rows)
# Four unmistakable flame heights, growing up from the SAME sill at y15.
# The flame occupies y11..14, y7..14, y3..14, then y1..14; its frame never moves.
# Empty/resident cells use inverse for blue panes, fire cells use red/orange.
for strength in range(1,5):
 for f in range(4):
    a=window_frame()
    peak=(4,8,12,14)[strength-1]
    dips=((3,1,0,2,1,3),(2,0,2,1,3,2),
          (3,2,1,3,0,2),(2,3,0,2,1,3))[f]
    for x in range(1,7):
        height=max(1,peak-dips[x-1])
        for y in range(15-height,15):
            a[y][x]=3
            if y>=15-max(1,height//2) and x in (2,3,4,5):
                a[y][x]=2
    window_tiles(16+(strength-1)*16+f*4,a)
# The resident stands inside the same y0..15 frame, with feet on the same sill.
resident=window_frame()
person=['000000','003300','033330','033330','003300','333333',
        '303303','003300','003300','003300','030030','030030',
        '030030','330033']
for y,row in enumerate(person,1):
    for x,v in enumerate(row,1): resident[y][x]=int(v)
window_tiles(80,resident)
# A 2x2-cell rubble patch: jagged loose masonry above, dense broken blocks below.
# Pixel values 1/2/3 use the burn scene's three grayscale playfield registers.
rubble=['00000000','00000000','00030000','00331000',
        '00331030','01100233','01223331','01223311',
        '22001102','22331122','10331022','11002203',
        '11223333','00333110','22301122','22112211']
for q in range(4):tile(84+q,[r[(q%2)*4:(q%2)*4+4] for r in rubble[(q//2)*8:(q//2)*8+8]])
P.joinpath('tiles.bin').write_bytes(b''.join(tiles))
# Compact hand-drawn 5x7 font, centered within an 8-pixel ANTIC 2 cell.
fontdata='''A 01110 10001 10001 11111 10001 10001 10001
B 11110 10001 10001 11110 10001 10001 11110
C 01111 10000 10000 10000 10000 10000 01111
D 11110 10001 10001 10001 10001 10001 11110
E 11111 10000 10000 11110 10000 10000 11111
F 11111 10000 10000 11110 10000 10000 10000
G 01111 10000 10000 10111 10001 10001 01111
H 10001 10001 10001 11111 10001 10001 10001
I 11111 00100 00100 00100 00100 00100 11111
J 00111 00010 00010 00010 10010 10010 01100
K 10001 10010 10100 11000 10100 10010 10001
L 10000 10000 10000 10000 10000 10000 11111
M 10001 11011 10101 10101 10001 10001 10001
N 10001 11001 10101 10011 10001 10001 10001
O 01110 10001 10001 10001 10001 10001 01110
P 11110 10001 10001 11110 10000 10000 10000
Q 01110 10001 10001 10001 10101 10010 01101
R 11110 10001 10001 11110 10100 10010 10001
S 01111 10000 10000 01110 00001 00001 11110
T 11111 00100 00100 00100 00100 00100 00100
U 10001 10001 10001 10001 10001 10001 01110
V 10001 10001 10001 10001 10001 01010 00100
W 10001 10001 10001 10101 10101 10101 01010
X 10001 10001 01010 00100 01010 10001 10001
Y 10001 10001 01010 00100 00100 00100 00100
Z 11111 00001 00010 00100 01000 10000 11111
0 01110 10001 10011 10101 11001 10001 01110
1 00100 01100 00100 00100 00100 00100 01110
2 01110 10001 00001 00010 00100 01000 11111
3 11110 00001 00001 01110 00001 00001 11110
4 00010 00110 01010 10010 11111 00010 00010
5 11111 10000 10000 11110 00001 00001 11110
6 01110 10000 10000 11110 10001 10001 01110
7 11111 00001 00010 00100 01000 01000 01000
8 01110 10001 10001 01110 10001 10001 01110
9 01110 10001 10001 01111 00001 00001 01110
: 00000 00100 00100 00000 00100 00100 00000
- 00000 00000 00000 11111 00000 00000 00000
! 00100 00100 00100 00100 00100 00000 00100
. 00000 00000 00000 00000 00000 00100 00100
/ 00001 00010 00010 00100 01000 01000 10000
+ 00000 00100 00100 11111 00100 00100 00000
< 00010 00100 01000 10000 01000 00100 00010
> 01000 00100 00010 00001 00010 00100 01000
? 01110 10001 00001 00010 00100 00000 00100'''
font=[bytes(8)]*128
font[ord("'")-32]=bytes([8,8,16,0,0,0,0,0])
for ln in fontdata.splitlines():
    c,*r=ln.split();font[ord(c)-32]=bytes([int(v,2)<<1 for v in r]+[0])
font[62]=bytes([0,126,126,126,126,126,126,0])
font[63]=bytes([0,126,66,66,66,66,126,0])
P.joinpath('font.bin').write_bytes(b''.join(font))
# Name, seconds, flames, toughness, wind, spread interval seconds, debris interval ticks, residents.
levels=[
('FIRST RESPONSE',30,4,1,0,0,80,0),('UPPER FLOORS',32,4,1,0,0,75,1),
('BLOCK PARTY',34,4,1,0,0,70,1),('HOT SPOTS',36,4,1,0,0,65,1),
('CALL FOR HELP',38,4,1,0,6,60,2),('EAST WIND',40,4,1,1,6,55,2),
('WEST WIND',40,4,1,2,6,50,2),('STUBBORN FLAMES',42,4,1,0,5,45,2),
('FALLING MASONRY',42,4,1,1,5,40,2),('CROSSWINDS',44,4,1,3,5,35,2),
('FIREBREAK',44,5,1,0,5,30,2),('ROOFTOP RESCUE',46,5,1,1,5,28,3),
('GUST FRONT',46,5,1,3,4,26,2),('OLD WAREHOUSE',48,5,1,2,4,24,2),
('NIGHT WATCH',48,5,1,3,4,22,3),('THE FIRE SPREADS',50,5,1,0,4,20,3),
('HIGH ALERT',50,5,1,3,3,18,3),('INFERNO',52,5,1,1,3,16,3),
('LAST CALL',52,5,1,2,3,14,3),('SAVE THE BLOCK',55,5,1,3,3,12,4)]
growth=[4,4,4,4,3,3,3,3,3,3,3,3,2,2,2,2,2,2,2,2]
wave_count=[10,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30]
wave_period=[100,95,90,85,80,75,75,70,70,65,65,60,60,60,55,55,55,50,50,45]
wave_cap=[5,5,5,6,6,6,6,6,6,6,7,7,7,7,7,7,8,8,8,8]
out=['; Generated level data. One byte per field.']
for i,l in enumerate(levels):out += [f'level_name_{i}: .byte '+','.join(str(ord(c)-32) for c in l[0].ljust(24))]
for field,n in enumerate(['seconds','count','strength','wind','spread','debris','residents'],1):out += [f'level_{n}: .byte '+','.join(str(l[field]) for l in levels)]
out+=['level_growth: .byte '+','.join(map(str,growth))]
for name,values in [('count',wave_count),('period',wave_period),('cap',wave_cap)]:out += ['level_wave_'+name+': .byte '+','.join(map(str,values))]
out+=['name_lo: .byte '+','.join(f'<level_name_{i}' for i in range(20)),'name_hi: .byte '+','.join(f'>level_name_{i}' for i in range(20))]
# Each layout has a repeatable permutation, chosen to avoid identical opening patterns.
for i in range(20):
    import random
    order=list(range(24));random.Random(8100+i).shuffle(order)
    if i==0:order=[18,9,22,4]+[x for x in order if x not in [18,9,22,4]]
    if i==1:order=[0,9,16,23,4]+[x for x in order if x not in [0,9,16,23,4]]
    out += [f'layout_{i}: .byte '+','.join(map(str,order))]
out+=['layout_lo: .byte '+','.join(f'<layout_{i}' for i in range(20)),'layout_hi: .byte '+','.join(f'>layout_{i}' for i in range(20))]
P.joinpath('levels.inc').write_text('\n'.join(out)+'\n')

geometry=[[7,12,17,22,27,32],[9,13,17,21,25,29],[7,11,15,24,28,32],[6,11,16,23,28,33]]
out=[]
for name,fn in [('geometry_x',lambda r,c:48+c*4),('geometry_lo',lambda r,c:(0x6000+(5+r*3)*40+c)&255),('geometry_hi',lambda r,c:(0x6000+(5+r*3)*40+c)>>8)]:
 for g,cols in enumerate(geometry):out += [f'{name}_{g}: .byte '+','.join(str(fn(r,c)) for r in range(4) for c in cols)]
 out += [f'{name}_lo: .byte '+','.join('<'+name+'_'+str(g) for g in range(4)),f'{name}_hi: .byte '+','.join('>'+name+'_'+str(g) for g in range(4))]
P.joinpath('geometry.inc').write_text('\n'.join(out)+'\n')
