"""Native ANTIC 4 title art. 160x192 logical pixels, 128 x 8 byte tiles.
All artwork is drawn as indexed code-native pixel art. No external image assets.
"""
from pathlib import Path
from PIL import Image, ImageDraw
P=Path(__file__).resolve().parents[1]
# Pixel 0 = blue-black sky; 1 = red; 2 = ivory; 3 = gold; 4 = blue (inverse).
im=Image.new('P',(160,192),0); d=ImageDraw.Draw(im)
font={}
for line in '''A 010 101 111 101 101
B 110 101 110 101 110
C 011 100 100 100 011
D 110 101 101 101 110
E 111 100 110 100 111
F 111 100 110 100 100
G 011 100 101 101 011
H 101 101 111 101 101
I 111 010 010 010 111
J 001 001 001 101 010
K 101 101 110 101 101
L 100 100 100 100 111
M 101 111 111 101 101
N 101 111 111 111 101
O 010 101 101 101 010
P 110 101 110 100 100
Q 010 101 101 111 011
R 110 101 110 101 101
S 011 100 010 001 110
T 111 010 010 010 010
U 101 101 101 101 111
V 101 101 101 101 010
W 101 101 111 111 101
X 101 101 010 101 101
Y 101 101 010 010 010
Z 111 001 010 100 111
0 111 101 101 101 111
2 110 001 010 100 111
6 011 100 111 101 111
: 000 010 000 010 000
/ 001 001 010 100 100
- 000 000 111 000 000
! 010 010 010 000 010'''.splitlines():
 c,*rows=line.split();font[c]=rows

def text(s,y,color=2,sx=1,sy=1,x=None):
 if x is None:x=(160-(len(s)*4-1)*sx)//2
 # Snap small text to character boundaries to reuse glyph tiles.
 if sx==sy==1:x=(x//4)*4
 for i,c in enumerate(s):
  for yy,row in enumerate(font.get(c,['000']*5)):
   for xx,v in enumerate(row):
    if v=='1':d.rectangle((x+(i*4+xx)*sx,y+yy*sy,x+(i*4+xx+1)*sx-1,y+(yy+1)*sy-1),fill=color)

def balloon(x,y):
 d.rectangle((x+2,y,x+5,y+1),fill=4)
 d.rectangle((x+1,y+2,x+6,y+7),fill=4)
 d.rectangle((x+2,y+8,x+5,y+9),fill=4)
 d.rectangle((x+3,y+10,x+4,y+12),fill=4)
 d.point((x+2,y+3),fill=2);d.point((x+2,y+4),fill=2)
 d.line((x+3,y+14,x+3,y+17),fill=2)

def flame(x,y):
 # Repeated two-cell-wide, two-cell-high silhouettes form the hero building.
 rows=['00000000','00000100','00100100','00101100','00111100','00111110','01131110','01133110','11333111','13333311','13323331','13322331','13322331','11322311','01133110','00111100']
 for yy,row in enumerate(rows):
  for xx,v in enumerate(row):
   if v!='0':im.putpixel((x+xx,y+yy),int(v))

# Broad two-line wordmark from the game's full 5x7 lettering.
large_font=(P/'src/font.bin').read_bytes()
def wordmark(s,y,color):
 x=((160-(len(s)*6-1)*2)//8)*4
 for dy,ink in [(1,1),(0,color)]:
  for i,c in enumerate(s):
   rows=large_font[(ord(c)-32)*8:(ord(c)-32)*8+7]
   for yy,b in enumerate(rows):
    for xx in range(5):
     if b & (1<<(5-xx)):
      d.rectangle((x+i*12+xx*2+dy,y+yy*3+dy,x+i*12+xx*2+1+dy,y+yy*3+2+dy),fill=ink)
wordmark('FIRE',7,3)
wordmark('BALLOON',39,2)
balloon(12,12);balloon(136,12)
# Sparse droplets guide the eye into the scene.
for x,y in [(28,72),(132,64),(140,88)]:
 d.rectangle((x,y,x+1,y+3),fill=4)
# Building facade in four aligned spans: repeated windows conserve charset RAM.
d.rectangle((44,76,115,123),fill=1)
d.rectangle((40,72,119,75),fill=2)
for y in [80,104]:
 for x in [48,64,80,96]:
  d.rectangle((x,y,x+7,y+15),fill=0)
  d.rectangle((x,y+15,x+7,y+15),fill=2)
  flame(x,y)
# Door and eaves.
d.rectangle((108,104,111,123),fill=0)
d.rectangle((40,124,119,127),fill=2)
# Waldo-like firefighter with red-white striped shirt, raised hand and bucket.
d.rectangle((24,93,27,95),fill=2)
d.rectangle((23,96,30,98),fill=1)
d.rectangle((24,99,29,104),fill=3)
d.rectangle((24,105,29,114),fill=1)
for y in (105,109,113):d.rectangle((24,y,29,y+1),fill=2)
d.rectangle((25,115,26,122),fill=4);d.rectangle((28,115,29,122),fill=4)
d.rectangle((24,123,26,124),fill=2);d.rectangle((28,123,31,124),fill=2)
d.line((30,108,33,102),fill=3,width=2)
d.line((22,107,21,116),fill=3,width=2)
d.rectangle((14,116,19,125),fill=2);d.rectangle((15,117,18,123),fill=4)
d.line((14,116,15,112,18,112,19,116),fill=2)
balloon(32,80)
# Road: white lane markings, no green.
d.rectangle((8,131,151,131),fill=2)
for x in range(16,152,24):d.rectangle((x,136,x+11,137),fill=2)
# Instructions use true 4-pixel character-aligned lettering.
text('MOVE: LEFT/RIGHT',144)
text('TAP FIRE: THROW',152)
text('HOLD FIRE: REFILL',160)
text('CREATED BY MARK2006',176,3)
text('PRESS FIRE/START',184,2)

# ANTIC 4 uses a per-cell inverse bit to substitute PF3 for PF2 (pixel 3).
patterns=[bytes(8)]; lookup={patterns[0]:0}; screen=[]
for cy in range(24):
 for cx in range(40):
  pixels=[[im.getpixel((cx*4+x,cy*8+y)) for x in range(4)] for y in range(8)]
  vals={v for row in pixels for v in row}
  if 3 in vals and 4 in vals:
   raise ValueError(f'Gold and blue share cell ({cx},{cy})')
  inverse=128 if 4 in vals else 0
  b=bytes(sum((3 if v==4 else v)<<(6-2*x) for x,v in enumerate(row)) for row in pixels)
  if b not in lookup:lookup[b]=len(patterns);patterns.append(b)
  screen.append(lookup[b]|inverse)
print(f'Title art: {len(patterns)} unique tiles / 128')
# Save a true pixel-aspect visual preview before enforcing the tile budget.
rgb=Image.new('RGB',im.size);palette=[(10,22,50),(194,49,42),(239,236,204),(251,179,63),(48,96,183)]
rgb.putdata([palette[im.getpixel((x,y))] for y in range(192) for x in range(160)]);P.joinpath('build').mkdir(exist_ok=True)
rgb.resize((640,384),Image.Resampling.NEAREST).save(P/'build/title-art.png')
assert len(patterns)<=128,'Title exceeds native 1K character set'
(P/'src/title_tiles.bin').write_bytes(b''.join(patterns)+bytes((128-len(patterns))*8))
(P/'src/title_screen.bin').write_bytes(bytes(screen))
