from pathlib import Path
import os, subprocess,struct,shutil
root=Path(__file__).resolve().parents[1]
subprocess.run(['python3',str(root/'tools/assets.py')],check=True)
subprocess.run(['python3',str(root/'tools/title_assets.py')],check=True)
binpath=os.environ.get('CC65_BIN')
def tool(n):
    result=shutil.which(n) or (str(Path(binpath)/n) if binpath else None)
    if not result: raise SystemExit('Install cc65 and put ca65/ld65 on PATH, or set CC65_BIN.')
    return result
b=root/'build';b.mkdir(exist_ok=True)
subprocess.run([tool('ca65'),'-g','-I',str(root/'src'),'-o',str(b/'game.o'),str(root/'src/game.s')],check=True)
subprocess.run([tool('ld65'),'-C',str(root/'src/linker.cfg'),'-m',str(b/'game.map'),'-Ln',str(b/'game.lbl'),'-o',str(b/'game.bin'),str(b/'game.o')],check=True)
def segment(addr,data): return struct.pack('<HH',addr,addr+len(data)-1)+data
labels={}
for line in (b/'game.lbl').read_text().splitlines():
    a=line.split()
    if len(a)==3: labels[a[2].lstrip('.')]=int(a[1],16)
xex=b'\xff\xff'+segment(0x2000,(b/'game.bin').read_bytes())+segment(0x8000,(b/'game.bin.assets').read_bytes())+segment(0x2e0,struct.pack('<H',labels['start']))
(b/'FIREBALLOON.xex').write_bytes(xex)
print('Built',len(xex),'bytes; code',len((b/'game.bin').read_bytes()))
