"""Controlled emulator checks for fire growth, burn-down, and a clean lower screen.

These scenarios intentionally write RAM to reach edge cases quickly. They are
separate from the unmodified twenty-level playthrough in playthrough.py.
"""

import json

from check import Emu, L, ROOT


BOTTOM = 0x6000 + 22 * 40
TARGET = 18


def put(e, label, index, value):
    e.poke(L[label] + index, value)


def clean_scene(e, strength=1, resident=True):
    """Use level one's calm weather and no spreading/debris for focused checks."""
    for name in ("fires", "residents", "fire_age"):
        for i in range(24):
            put(e, name, i, 0)
    for i in range(5):
        put(e, "shot_y", i, 0)
    for name in ("secondtick", "debris_y", "throwphase", "cooldown",
                 "wave_left", "wave_clock", "press_ticks", "throw_queued", "refill_clock"):
        e.poke(name, 0)
    e.poke("seconds", 200)
    put(e, "fires", TARGET, strength)
    if resident:
        # Keeps play active after extinguishing TARGET.
        put(e, "residents", 0, 1)


def next_second(e):
    e.poke("secondtick", 49)
    e.step(3)


def hit_target(e):
    # A real balloon collision is processed by the game's normal update routine.
    put(e, "shot_x", 0, e.mem("win_x", 24)[TARGET] + 2)
    put(e, "shot_y", 0, e.mem("win_y", 24)[TARGET] + 10)
    e.step(3)


def bottom_clear(e, context):
    cells = e.mem(BOTTOM, 80)
    assert cells == bytes(80), (context, "lower-screen text", cells.hex())
    assert any(e.mem(0x6000, 80)), (context, "top HUD disappeared")


def await_state(e, target, max_frames=600):
    for _ in range(max_frames):
        if e.val("state") == target:
            return
        e.step()
    raise AssertionError(("state transition", target, e.val("state")))


def check_tv(tv, rate):
    e = Emu(tv)
    checks = []
    try:
        e.boot()
        assert e.val("fps") == rate
        bottom_clear(e, "play")
        clean_scene(e)
        limit = e.val("grow_limit")
        assert limit > 1

        # Full elapsed-time check: NTSC and PAL both grow after the same number
        # of real seconds; no artificial age/timer advance in this portion.
        e.step(rate * (limit - 1) + 3)
        assert e.mem("fires", 24)[TARGET] == 1
        assert e.mem("fire_age", 24)[TARGET] == limit - 1
        e.step(rate)
        assert e.mem("fires", 24)[TARGET] == 2
        assert e.mem("fire_age", 24)[TARGET] == 0
        checks.append("real_time_growth")

        for expected in (3, 4):
            put(e, "fire_age", TARGET, limit - 1)
            next_second(e)
            assert e.val("state") == 1
            assert e.mem("fires", 24)[TARGET] == expected
            assert e.mem("fire_age", 24)[TARGET] == 0
        assert not any(e.mem("fire_age", 24)[:TARGET])
        checks.append("four_fire_stages")

        # A successful hit cools critical fire and restarts its growth clock.
        put(e, "fire_age", TARGET, limit - 1)
        e.poke("secondtick", 10)
        hit_target(e)
        assert e.mem("fires", 24)[TARGET] == 3
        assert e.mem("fire_age", 24)[TARGET] == 0
        assert e.val("state") == 1
        checks.append("water_resets_growth")

        # On a fire's last safe simulation tick, water gets a chance to save it.
        put(e, "fires", TARGET, 4)
        put(e, "fire_age", TARGET, limit - 1)
        e.poke("secondtick", 49)
        before_lives = e.val("lives")
        before_burns = e.val("burn_count")
        hit_target(e)
        assert e.val("state") == 1
        assert e.mem("fires", 24)[TARGET] == 3
        assert e.mem("fire_age", 24)[TARGET] <= 1
        assert e.val("lives") == before_lives
        assert e.val("burn_count") == before_burns
        checks.append("deadline_water_save")

        # Extinguished windows never retain a nearly expired age.
        put(e, "fires", TARGET, 1)
        put(e, "fire_age", TARGET, limit - 1)
        e.poke("secondtick", 10)
        hit_target(e)
        assert e.mem("fires", 24)[TARGET] == 0
        assert e.mem("fire_age", 24)[TARGET] == 0
        assert e.val("state") == 1
        checks.append("extinguish_clears_age")

        clean_scene(e)
        put(e, "fire_age", TARGET, limit - 1)
        e.step(3, sel=1)
        assert e.val("state") == 7
        frozen = (e.mem("fire_age", 24), e.mem("fires", 24), e.val("seconds"))
        e.step(rate * 3, sel=1, t=1, j=8)
        assert frozen == (e.mem("fire_age", 24), e.mem("fires", 24), e.val("seconds"))
        bottom_clear(e, "pause")
        e.step(3)
        e.step(3, sel=1)
        e.step(3)
        assert e.val("state") == 1
        bottom_clear(e, "resume")
        checks.append("pause_freezes_growth")

        # Several critical fires expiring together still cost exactly one life.
        clean_scene(e, 4)
        put(e, "fires", TARGET + 1, 4)
        put(e, "fire_age", TARGET, limit - 1)
        put(e, "fire_age", TARGET + 1, limit - 1)
        before_lives = e.val("lives")
        before_burns = e.val("burn_count")
        next_second(e)
        assert e.val("state") == 8
        assert e.val("lives") == before_lives - 1
        assert e.val("burn_count") == before_burns + 1
        bottom_clear(e, "burn start")
        e.step(rate, t=1, j=8)
        assert e.val("state") == 8
        assert e.val("lives") == before_lives - 1
        assert e.val("burn_count") == before_burns + 1
        bottom_clear(e, "burn animation")
        e.shot(tv + "-growth-burndown")
        await_state(e, 2)
        assert e.val("lives") == before_lives - 1
        e.step(40)
        e.press()
        assert e.val("state") == 1
        assert not any(e.mem("fire_age", 24))
        bottom_clear(e, "burn retry")
        checks.append("burndown_once_and_retry")

        # Ordinary timeout and success still leave the lower two rows empty.
        clean_scene(e)
        e.poke("seconds", 1)
        next_second(e)
        assert e.val("state") == 4
        bottom_clear(e, "timeout")
        await_state(e, 2)
        e.step(40)
        e.press()
        assert e.val("state") == 1
        clean_scene(e, resident=False)
        hit_target(e)
        assert e.val("state") == 3
        bottom_clear(e, "level clear")
        checks.append("bottom_blank_all_gameplay_states")

        # Burning the building on the final life reaches game over, not a retry.
        await_state(e, 2)
        e.step(40)
        e.press()
        assert e.val("state") == 1
        clean_scene(e, 4)
        e.poke("lives", 1)
        put(e, "fire_age", TARGET, e.val("grow_limit") - 1)
        next_second(e)
        assert e.val("state") == 8 and e.val("lives") == 0
        await_state(e, 5)
        checks.append("final_life_burndown_gameover")

        # A newly ignited neighbor starts its own clock. Exercise the real
        # level-eleven spread interval, including a deliberately stale slot age.
        e.press()
        assert e.val("state") == 2
        e.poke("level", 10)
        e.step(40)
        e.press()
        assert e.val("state") == 1
        clean_scene(e)
        put(e, "fire_age", TARGET + 1, e.val("grow_limit") - 1)
        interval = e.mem("level_spread", 20)[e.val("level")]
        assert interval > 0
        e.poke("spreadclock", interval - 1)
        next_second(e)
        assert e.mem("fires", 24)[TARGET + 1] == 1
        assert e.mem("fire_age", 24)[TARGET + 1] <= 1
        assert sum(bool(v) for v in e.mem("fires", 24)) == 2
        checks.append("spread_starts_new_growth_clock")
        return {"tv": tv, "initial_growth_seconds": limit, "checks": checks, "result": "PASS"}
    finally:
        e.close()


if __name__ == "__main__":
    result = [check_tv("ntsc", 60), check_tv("pal", 50)]
    report = json.dumps(result, indent=2)
    print(report)
    (ROOT / "build/growth-regression.json").write_text(report + "\n")
