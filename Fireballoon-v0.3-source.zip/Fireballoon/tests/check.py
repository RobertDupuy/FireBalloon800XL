from pathlib import Path
import subprocess,json
ROOT=Path(__file__).resolve().parents[1]
L={}
for ln in (ROOT/'build/game.lbl').read_text().splitlines():
 a=ln.split()
 if len(a)==3:L[a[2].lstrip('.')]=int(a[1],16)
class Emu:
 def __init__(self,tv='ntsc'):
  self.p=subprocess.Popen([str(ROOT/'build/emulator'),'-'+tv,str(ROOT/'build/FIREBALLOON.xex')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=open('/tmp/fireballoon-'+tv+'.log','w'),text=True)
  while self.p.stdout.readline().strip()!="READY":
   if self.p.poll() is not None:raise RuntimeError("init failed")
 def cmd(self,c):
  self.p.stdin.write(c+'\n');self.p.stdin.flush();a=self.p.stdout.readline().strip()
  if not a:raise RuntimeError('Emulator stopped: '+c)
  return a
 def step(self,n=1,j=0,t=0,start=0,sel=0):self.cmd(f'step {n} {j} {t} {start} {sel}')
 def mem(self,a,n=1):return bytes.fromhex(self.cmd(f'mem {L.get(a,a)} {n}'))
 def val(self,a):return self.mem(a)[0]
 def poke(self,a,v):self.cmd(f'poke {L.get(a,a)} {v}')
 def shot(self,name):self.cmd(f'shot {ROOT}/build/{name}.ppm')
 def press(self):self.step(3,t=1);self.step(40)
 def boot(self):self.step(150);assert self.val('frames')!=0;self.press();assert self.val('state')==2;self.press();assert self.val('state')==1
 def close(self):self.p.stdin.write('quit\n');self.p.stdin.flush();self.p.wait()
if __name__=='__main__':
 e=Emu();e.boot();e.step(120);e.step(40,j=4,t=1);e.shot('game')
 for n in ['state','fps','player_x','shot_x','shot_y','hits','misses','tick','frames','logic_count']:print(n,e.mem(n,5 if n.startswith('shot_') else 2).hex())
 e.close()
