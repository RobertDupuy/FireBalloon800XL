"""Record native title and two gameplay examples with actual POKEY sound.

Requires the bundled emulator harness, Pillow, NumPy, and FFmpeg. The second
call is selected in the level transition to demonstrate late fire pressure.
No fires, timers, lives, ammo, or hazard state are altered for the recording.
"""
from pathlib import Path
import subprocess,json,numpy as np
from check import Emu,ROOT
from balance_probe import Snapshot,Bot
W=ROOT/'build/audio-preview';W.mkdir(exist_ok=True)
e=Emu();e.step(150)
meta=e.cmd(f'record {W}/video.rgb {W}/audio.pcm').split()
rate,channels,width=map(int,meta[:3]);fps=float(meta[3])
e.step(120);e.press();e.step(45);e.press();bot=Bot('urgent')
first={}
for frame in range(0,2400,2):
 if e.val('state')!=1:break
 j,t=bot.action(Snapshot(e));e.step(2,j,t)
first={'state':e.val('state'),'seconds_left':e.val('seconds')}
# Select a late call only after active gameplay has ended.
if e.val('state')==3:
 e.poke('level',18);e.step(150)
elif e.val('state') in (4,8):
 e.poke('level',19);e.step(230)
if e.val('state')==2:
 e.step(80);e.press();bot=Bot('urgent')
 for frame in range(0,1200,2):
  if e.val('state')!=1:break
  j,t=bot.action(Snapshot(e));e.step(2,j,t)
 e.step(190)
frames=int(e.cmd('recordstop'));e.close()
assert width==2 and channels==1
samples=np.fromfile(W/'audio.pcm',dtype='<i2')
assert samples.size>rate*10 and np.std(samples)>25
report={'sample_rate':rate,'channels':channels,'emulator_fps':fps,'recorded_frames':frames,'pcm_duration_seconds':len(samples)/rate,'video_duration_seconds':frames/fps,'first_call':first,'setup':'native title, natural first call, then call20 selected during transition','peak_dbfs':float(20*np.log10(max(1,np.abs(samples.astype(float)).max())/32768)),'rms_dbfs':float(20*np.log10(np.sqrt(np.mean(samples.astype(float)**2))/32768))}
(ROOT/'build/video-preview.json').write_text(json.dumps(report,indent=2)+'\n')
output=ROOT/'build/Fireballoon-v0.3-with-sound.mp4'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-video_size','384x240','-framerate',str(fps/2),'-i',str(W/'video.rgb'),'-f','s16le','-ar',str(rate),'-ac',str(channels),'-i',str(W/'audio.pcm'),'-vf','crop=336:208:24:16,scale=1008:624:flags=neighbor','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart','-shortest',str(output)],check=True)
print(json.dumps(report,indent=2));print(output,output.stat().st_size)
