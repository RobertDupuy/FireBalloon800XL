"""Compatibility entry point for v0.3 controls and fire-pressure checks.

These are controlled functional checks; balance_probe.py records playing
outcomes separately and does not assert that all twenty calls are beatable.
"""
from pathlib import Path
import runpy

runpy.run_path(str(Path(__file__).with_name("action_regression.py")), run_name="__main__")
