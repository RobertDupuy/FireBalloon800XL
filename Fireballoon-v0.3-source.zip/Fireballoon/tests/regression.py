"""Compatibility entry point for the current native functional regressions."""
from pathlib import Path
import runpy

for suite in ("action_regression.py", "growth_regression.py", "window_art_regression.py"):
    runpy.run_path(str(Path(__file__).with_name(suite)), run_name="__main__")
