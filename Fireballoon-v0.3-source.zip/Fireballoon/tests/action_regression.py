"""v0.3 controlled input, outbreak, presentation, and timing regressions.

Memory writes isolate edge cases; these checks are not human playtesting or a
joystick-only campaign completion claim. A separate untouched idle run measures
how quickly an unattended opening fire grows and hazards cost a life.
"""
import hashlib
import json
from check import Emu, L, ROOT


def count(e, name):
    return int.from_bytes(e.mem(name, 2), 'little')


def ticks(e, amount, **inputs):
    start = count(e, 'logic_count')
    for _ in range(amount * 3 + 10):
        if (count(e, 'logic_count') - start) & 65535 >= amount:
            return
        e.step(**inputs)
    raise AssertionError('simulation stopped')


def await_value(e, name, wanted, max_frames=240, **inputs):
    for _ in range(max_frames):
        if e.val(name) == wanted:
            return
        e.step(**inputs)
    raise AssertionError((name, wanted, e.val(name)))


def put(e, label, index, value):
    e.poke(L[label] + index, value)


def scene(e, water=8, strength=1):
    e.step(3)
    for name in ('fires', 'residents', 'fire_age'):
        for i in range(24):
            put(e, name, i, 0)
    put(e, 'fires', 0, strength)
    for i in range(5):
        put(e, 'shot_y', i, 0)
    for name in ('secondtick', 'debris_y', 'debrisclock', 'spreadclock',
                 'throwphase', 'cooldown', 'refill_clock', 'press_ticks',
                 'throw_queued', 'wave_left', 'wave_clock'):
        e.poke(name, 0)
    e.poke('water', water)
    e.poke('seconds', 200)
    e.poke('player_x', 110)
    e.poke('invincible', 100)


def bottom_clear(e, context):
    assert e.mem(0x6000 + 22 * 40, 80) == bytes(80), context


def natural_pressure(tv, rate):
    e = Emu(tv)
    try:
        e.step(150)
        e.press()
        assert e.val('state') == 2
        await_value(e, 'state', 1, t=1)
        e.step()  # Release entry FIRE; beginlevel suppresses this first release.
        initial = list(e.mem('fires', 24))
        stages = {i: v for i, v in enumerate(initial) if v}
        before_lives = e.val('lives')
        first_growth = None
        max_frames = rate * 20
        for frame in range(1, max_frames + 1):
            e.step()
            current = e.mem('fires', 24)
            if first_growth is None and any(current[i] > v for i, v in stages.items()):
                first_growth = frame / rate
            if e.val('state') in (4, 8):
                break
        else:
            raise AssertionError((tv, 'untouched opening did not cost a life within 20 seconds'))
        assert first_growth is not None and first_growth <= 4.1, first_growth
        assert frame / rate <= 16.1, frame / rate
        assert e.val('lives') == before_lives - 1
        return {'first_visible_growth_seconds': round(first_growth, 3),
                'untouched_life_loss_seconds': round(frame / rate, 3),
                'untouched_loss_cause': 'building_burn' if e.val('state') == 8 else 'debris'}
    finally:
        e.close()


def controlled_burn_deadlines(tv, rate):
    """Isolate natural fire timers; suppress debris damage using test RAM writes."""
    results = []
    for level in (0, 19):
        e = Emu(tv)
        try:
            e.boot()
            if level:
                e.poke('level', level)
                e.poke('state', 2)
                e.press()
                assert e.val('state') == 1
            scene(e)
            limit = e.val('grow_limit')
            transitions = []
            old_stage = 1
            for frame in range(1, rate * 20 + 1):
                # This fixture intentionally suppresses brick damage. It never
                # changes fire strength, age, countdown, or simulation speed.
                if frame % 100 == 1:
                    e.poke('invincible', 255)
                e.step()
                stage = e.mem('fires', 24)[0]
                if stage != old_stage:
                    transitions.append([stage, round(frame / rate, 3)])
                    old_stage = stage
                if e.val('state') == 8:
                    break
            else:
                raise AssertionError((tv, level + 1, 'isolated fire never burned'))
            assert [v for v, _ in transitions] == [2, 3, 4], transitions
            for stage, elapsed in transitions:
                assert abs(elapsed - (stage - 1) * limit) <= 0.08, transitions
            assert abs(frame / rate - 4 * limit) <= 0.08, frame / rate
            results.append({'level': level + 1, 'stage_transitions_seconds': transitions,
                            'burn_seconds': round(frame / rate, 3),
                            'fixture': 'one fire, waves off, debris damage suppressed'})
        finally:
            e.close()
    return results


def check_tv(tv, rate):
    e = Emu(tv)
    checks = []
    try:
        e.step(150)
        assert e.val('screenmode') == 2
        assert e.mem(0x6000, 960) == (ROOT / 'src/title_screen.bin').read_bytes()
        assert e.mem(0x6400, 1024) == (ROOT / 'src/title_tiles.bin').read_bytes()
        e.shot(tv + '-v03-title')
        checks.append('graphical_title_exact_native_assets')
        e.press()
        assert e.val('state') == 2
        e.press()
        assert e.val('state') == 1
        assert count(e, 'shot_count') == 0, 'entry button leaked into gameplay shot'
        assert e.mem(0x6400, 1024) == (ROOT / 'src/tiles.bin').read_bytes()
        bottom_clear(e, 'play')
        checks.append('gameplay_restores_charset_and_blank_lower_screen')

        scene(e)
        before = count(e, 'shot_count')
        ticks(e, 3, t=1)
        assert count(e, 'shot_count') == before
        assert e.val('throwphase') == 0
        assert e.val('water') == 8
        e.step(3)
        assert e.val('throwphase') > 6
        assert e.val('water') == 8
        await_value(e, 'water', 7)
        assert count(e, 'shot_count') == before + 1
        ticks(e, 30)
        assert count(e, 'shot_count') == before + 1
        assert e.val('water') == 7
        checks.append('tap_release_throws_once_and_spends_only_at_launch')

        scene(e, water=0)
        before = count(e, 'shot_count')
        ticks(e, 3, t=1)
        ticks(e, 35)
        assert count(e, 'shot_count') == before
        assert e.val('water') == 0
        checks.append('empty_tap_cannot_create_balloon')

        # Top up a partially full bucket without DOWN and before running out.
        scene(e, water=3)
        before = count(e, 'shot_count')
        refills = e.val('refill_count')
        hud_before = e.mem(0x6000 + 40, 40)
        start = count(e, 'logic_count')
        await_value(e, 'press_ticks', 25, t=1)
        assert 24 <= e.val('refill_clock') <= 25
        assert e.val('water') == 3
        ticks(e, 2, t=1)
        assert e.mem(0x6000 + 40, 40) != hud_before, 'refill progress is not displayed'
        await_value(e, 'press_ticks', 49, t=1)
        assert e.val('water') == 3 and e.val('refill_count') == refills
        await_value(e, 'water', 8, t=1)
        elapsed = (count(e, 'logic_count') - start) & 65535
        assert 50 <= elapsed <= 52, elapsed
        assert e.val('refill_count') == (refills + 1) & 255
        ticks(e, 70, t=1)
        assert e.val('press_ticks') == 50
        assert e.val('water') == 8
        assert e.val('refill_count') == (refills + 1) & 255
        assert count(e, 'shot_count') == before
        ticks(e, 35)
        assert e.val('press_ticks') == 0 and e.val('refill_clock') == 0
        assert count(e, 'shot_count') == before
        bottom_clear(e, 'refill')
        checks.extend(('one_second_fire_hold_tops_up_partial_bucket',
                       'visible_refill_progress', 'hold_refills_once_without_firing',
                       'completed_hold_release_suppresses_throw'))

        scene(e, water=8)
        refills = e.val('refill_count')
        before = count(e, 'shot_count')
        ticks(e, 65, t=1)
        ticks(e, 35)
        assert e.val('water') == 8 and e.val('refill_count') == refills
        assert count(e, 'shot_count') == before
        checks.append('holding_full_bucket_neither_spends_nor_counts_refill')

        scene(e, water=2)
        before_x = e.val('player_x')
        e.poke('debris_y', 100)
        e.poke('debris_x', 180)
        ticks(e, 15, j=8, t=1)
        assert e.val('player_x') > before_x
        assert e.val('debris_y') > 100
        ticks(e, 40, t=1)
        assert e.val('water') == 8
        assert e.val('seconds') == 199 and e.mem('fire_age', 24)[0] == 1
        checks.append('movement_timer_fire_and_debris_continue_during_charge')

        scene(e, water=2)
        ticks(e, 60, j=2)
        assert e.val('water') == 2 and e.val('refill_clock') == 0
        checks.append('down_is_not_a_hidden_refill_control')

        scene(e, water=2)
        ticks(e, 20, t=1)
        await_value(e, 'state', 7, t=1, sel=1)
        names = ('water', 'press_ticks', 'refill_clock', 'seconds', 'secondtick',
                 'wave_clock', 'wave_left')
        frozen = tuple(e.val(name) for name in names) + (e.mem('fire_age', 24),)
        e.step(rate * 2, t=1, sel=1)
        assert frozen == tuple(e.val(name) for name in names) + (e.mem('fire_age', 24),)
        bottom_clear(e, 'pause')
        e.step(3, t=1)
        await_value(e, 'state', 1, t=1, sel=1)
        await_value(e, 'water', 8, t=1)
        ticks(e, 2)
        checks.append('pause_freezes_partial_charge_and_hazards')

        # Pending outbreaks prevent a lull from counting as level completion.
        scene(e)
        put(e, 'fires', 0, 0)
        e.poke('wave_left', 1)
        e.poke('wave_clock', 0)
        e.poke('wave_period', 30)
        e.poke('wave_cap', 5)
        before_spawns = e.val('spawn_count')
        ticks(e, 10)
        assert e.val('state') == 1 and not any(e.mem('fires', 24))
        await_value(e, 'wave_left', 0)
        ticks(e, 2)
        assert e.val('spawn_count') == (before_spawns + 1) & 255
        assert sum(v > 0 for v in e.mem('fires', 24)) == 1
        assert sum(e.mem('fire_age', 24)) == 0
        checks.append('pending_outbreak_prevents_early_clear_and_starts_fresh_fire')

        scene(e)
        e.poke('wave_left', 2)
        e.poke('wave_period', 10)
        e.poke('wave_cap', 1)
        before_spawns = e.val('spawn_count')
        ticks(e, 30)
        assert e.val('wave_left') == 2 and e.val('spawn_count') == before_spawns
        put(e, 'fires', 0, 0)
        await_value(e, 'wave_left', 1)
        assert e.val('spawn_count') == (before_spawns + 1) & 255
        checks.append('outbreak_waits_at_cap_without_losing_budget')

        scene(e)
        for i in range(24):
            put(e, 'fires', i, 0)
        ticks(e, 3)
        assert e.val('state') == 3
        bottom_clear(e, 'clear')
        checks.append('clear_requires_no_fires_residents_or_pending_outbreaks')

        growth = list(e.mem('level_growth', 20))
        assert max(growth) <= 4 and min(growth) <= 2
        assert all(a >= b for a, b in zip(growth, growth[1:]))
        checks.append('campaign_growth_accelerates_four_to_two_seconds')
        return {'tv': tv, 'result': 'PASS', 'growth_seconds': growth,
                'checks': checks, 'natural_pressure': natural_pressure(tv, rate),
                'controlled_burn_deadlines': controlled_burn_deadlines(tv, rate)}
    finally:
        e.close()


if __name__ == '__main__':
    report = {'xex_sha256': hashlib.sha256((ROOT / 'build/FIREBALLOON.xex').read_bytes()).hexdigest(),
              'scenarios': [check_tv('ntsc', 60), check_tv('pal', 50)]}
    text = json.dumps(report, indent=2)
    print(text)
    (ROOT / 'build/action-regression.json').write_text(text + '\n')
