"""Natural campaign probe: joystick only, no writes to game memory.

This is a difficulty measurement, not a requirement that one fixed strategy
win. --require-win makes an incomplete campaign fail when used as a gate.
"""
from check import Emu,ROOT
from balance_probe import Snapshot,Bot
from pathlib import Path
import argparse,json,hashlib

def run(tv,mode='urgent'):
 e=Emu(tv);e.boot();bot=Bot(mode);levels=[];losses=[];frames=0
 try:
  while frames<100000:
   s=Snapshot(e);state=s.v('state');lev=s.v('level')+1
   if state in (5,6):break
   if state==2:
    e.step(40);e.press();frames+=83;bot=Bot(mode);continue
   if state==3:
    levels.append({'level':lev,'seconds_left':s.v('seconds'),'lives':s.v('lives'),'shots':s.u16('shot_count'),'hits':s.u16('hits'),'refills':s.v('refill_count')})
    print(tv,levels[-1],flush=True)
    e.step(140);frames+=140;continue
   if state in (4,8):
    losses.append({'level':lev,'cause':'burn' if state==8 else 'timeout' if s.v('seconds')==0 else 'debris','seconds_left':s.v('seconds')})
    e.step(210);frames+=210;continue
   j,t=bot.action(s);e.step(2,j,t);frames+=2
  return {'tv':tv,'bot':mode,'setup':'natural campaign; no game memory writes','outcome':'victory' if e.val('state')==6 else 'game_over' if e.val('state')==5 else 'probe_limit','levels':levels,'losses':losses,'emulator_frames':frames,'xex_sha256':hashlib.sha256((ROOT/'build/FIREBALLOON.xex').read_bytes()).hexdigest()}
 finally:e.close()

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--tv',choices=['ntsc','pal','both'],default='both');p.add_argument('--bot',choices=['greedy','urgent'],default='urgent');p.add_argument('--require-win',action='store_true');a=p.parse_args()
 out=[run(tv,a.bot) for tv in (['ntsc','pal'] if a.tv=='both' else [a.tv])]
 (ROOT/'build/playthrough.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps([{k:v for k,v in r.items() if k!='levels'} for r in out],indent=2))
 if a.require_win:assert all(r['outcome']=='victory' for r in out),'Fixed policy did not complete every campaign'
