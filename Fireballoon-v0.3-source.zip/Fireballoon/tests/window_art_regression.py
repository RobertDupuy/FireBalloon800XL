"""Check the shipped charset for stationary windows and distinct fire sizes."""
from pathlib import Path
import json


def unpack_window(charset, base):
    pixels = [[0] * 8 for _ in range(16)]
    for q in range(4):
        for y, byte in enumerate(charset[(base + q) * 8:(base + q + 1) * 8]):
            for x in range(4):
                pixels[(q // 2) * 8 + y][(q % 2) * 4 + x] = (
                    byte >> (6 - 2 * x)) & 3
    return pixels


def verify(charset):
    assert len(charset) == 1024
    perimeter = [(x, y) for y in range(16) for x in range(8)
                 if x in (0, 7) or y in (0, 15)]
    empty = unpack_window(charset, 3)
    resident = unpack_window(charset, 80)
    for label, pixels in [('empty', empty), ('resident', resident)]:
        assert all(pixels[y][x] == 2 for x, y in perimeter), label
    areas = []
    peaks = []
    for strength, height in enumerate((4, 8, 12, 14), 1):
        stage_areas = []
        frames = []
        for frame in range(4):
            pixels = unpack_window(charset, 16 + (strength - 1) * 16 + frame * 4)
            assert all(pixels[y][x] == empty[y][x] for x, y in perimeter), (
                'Frame/sill moved', strength, frame)
            flame = [(x, y) for y in range(1, 15) for x in range(1, 7)
                     if pixels[y][x] in (2, 3)]
            assert min(y for _, y in flame) == 15 - height, (strength, frame)
            assert max(y for _, y in flame) == 14, (strength, frame)
            assert all(pixels[14][x] in (2, 3) for x in range(1, 7))
            stage_areas.append(len(flame))
            frames.append(tuple(tuple(row) for row in pixels))
        assert len(set(frames)) == 4, ('Animation is static', strength)
        areas.append(stage_areas)
        peaks.append(height)
    for previous, current in zip(areas, areas[1:]):
        assert max(previous) < min(current), ('Growth not clearly visible', areas)
    return {'window_frame_bounds': [0, 0, 7, 15], 'flame_base_y': 14,
            'flame_heights': peaks, 'stage_flame_pixel_counts': areas,
            'stationary_frame_states_checked': 18, 'passed': True}


if __name__ == '__main__':
    charset = Path(__file__).resolve().parents[1] / 'src' / 'tiles.bin'
    print(json.dumps(verify(charset.read_bytes()), indent=2))
