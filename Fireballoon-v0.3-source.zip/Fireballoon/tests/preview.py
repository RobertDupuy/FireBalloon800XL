"""Native NTSC excerpt at normal speed, with level 16 selected in its briefing."""
from check import Emu,ROOT
from balance_probe import Snapshot,Bot
from PIL import Image

e=Emu();e.step(150);e.press();e.poke('level',15);e.press()
bot=Bot('greedy');frames=[]
for n in range(320):
 if e.val('state')!=1:break
 j,t=bot.action(Snapshot(e));e.step(3,j,t)
 if n%2:continue
 e.cmd('shot /tmp/fireballoon-preview.ppm')
 im=Image.open('/tmp/fireballoon-preview.ppm').convert('RGB').crop((24,16,360,224)).resize((1008,624),Image.Resampling.NEAREST)
 frames.append(im.copy())
 if n==120:im.save(ROOT/'build/Fireballoon-preview.png')
frames[0].save(ROOT/'build/Fireballoon-preview.gif',save_all=True,append_images=frames[1:],duration=100,loop=0,optimize=True)
e.close()
