"""Isolated-level balance probes, not a natural campaign completion test.

Only the requested level is selected by a memory write, while on the intro.
Once play starts both policies use joystick input and read game memory only.
Urgent uses exact memory for aiming/balloon forecasting: an upper-bound player,
not evidence that an unpractised human can complete the same difficulty.
"""
from check import Emu, L, ROOT
import argparse, json, hashlib

class Snapshot:
 def __init__(self,e):
  self.m=e.mem(0x5000,1024)
 def v(self,k,default=0):
  return self.m[L[k]-0x5000] if k in L else default
 def a(self,k,n):
  return list(self.m[L[k]-0x5000:L[k]-0x5000+n])
 def u16(self,k):
  a=self.a(k,2);return a[0]+256*a[1]

def aim(s,i):
 flight=(184-(72+i//6*24)-14)//2
 wind=s.v('winddir');drift=flight//8*(1 if wind==1 else -1 if wind==2 else 0)
 return s.a('win_x',24)[i]+2-7-drift

def forecast(s):
 """Predict first window hit by every airborne balloon, in time order."""
 health=s.a('fires',24);people=s.a('residents',24);wx=s.a('win_x',24)
 shots=[[x,y] for x,y in zip(s.a('shot_x',5),s.a('shot_y',5)) if y]
 wind=s.v('winddir');drift=1 if wind==1 else -1 if wind==2 else 0
 for dt in range(1,61):
  for shot in shots:
   if not shot[1]:continue
   shot[1]-=2
   if shot[1]<68:shot[1]=0;continue
   if (s.v('tick')+dt)%8==0:shot[0]+=drift
   for i in range(24):
    if (health[i] or people[i]) and 0<=shot[1]-(72+i//6*24)<16 and -3<=shot[0]-wx[i]<9:
     if health[i]:health[i]-=1
     else:people[i]=0
     shot[1]=0;break
 return health,people

class Bot:
 deadline_weight=.075
 goal_bonus=0.0
 refill_threshold=0
 late_deadline_weight=.6
 def __init__(self,mode):self.mode=mode;self.lock=None;self.refilling=False;self.goal=None
 def action(self,s):
  if self.mode=='idle':return 0,0
  if self.mode=='hold':return 0,1
  x=s.v('player_x');fires=s.a('fires',24);people=s.a('residents',24)
  age=s.a('fire_age',24);limit=s.v('grow_limit',255)
  tap_controls='press_ticks' in L
  water=s.v('water',8)
  if water==0:self.refilling=True
  if tap_controls and 0<water<=self.refill_threshold and not s.v('press_ticks') and s.v('throwphase')<=6 and not s.v('throw_queued'):
   pending,_=forecast(s)
   deadlines=[(5-pending[i])*limit-(age[i] if pending[i]==fires[i] else 0) for i in range(24) if pending[i]]
   if not deadlines or min(deadlines)>2:self.refilling=True
  # New controls allow moving while holding fire to refill. The earlier
  # version's down-to-refill policy remains available for comparison builds.
  dy=s.v('debris_y');bx=s.v('debris_x');speed=2.5 if s.v('level')>=14 else 2 if s.v('level')>=8 else 1.5
  danger=dy and dy>187-speed*18 and abs(bx-x)<13 and not s.v('invincible')
  if danger:
   if not tap_controls:self.refilling=False
   self.lock=None;self.goal=None
   return (8 if bx<73 or (x>=bx and bx<179) else 4),int(tap_controls and self.refilling)
  if self.refilling:
   if water>=8:
    self.refilling=False
    if tap_controls:return 0,0 # Releasing a completed hold must not throw.
   elif not tap_controls:return 2,0
   else:
    self.lock=None
    candidates=[((5-fires[i])*limit-age[i] if fires[i] else 200,abs(x-aim(s,i)),aim(s,i)) for i in range(24) if fires[i] or people[i]]
    tx=min(candidates)[2] if candidates else 120
    j=8 if tx-x>1 else 4 if tx-x<-1 else 0
    if dy and dy>145 and j and abs(bx-(x+(2 if j==8 else -2)))<14:j=0
    return j,1
  if self.mode=='greedy':
   targets=[(abs(x-aim(s,i))+(3-i//6)*3,aim(s,i),i) for i in range(24) if fires[i] or people[i]]
  else:
   left,remaining_people=forecast(s)
   # Stay at the selected aim until the held balloon actually leaves the hand.
   if (s.v('throwphase')>6 or s.v('throw_queued') or (tap_controls and 0<s.v('press_ticks')<50)) and self.lock is not None:
    dx=self.lock-x
    return (8 if dx>1 else 4 if dx<-1 else 0),0
   self.lock=None
   targets=[]
   for i in range(24):
    if not left[i] and not remaining_people[i]:continue
    tx=aim(s,i);travel=abs(tx-x)/50
    deadline=(5-left[i])*limit-(age[i] if left[i]==fires[i] else 0) if left[i] else 200
    # Upper windows can be blocked by lower windows. Give their urgent
    # deadline to that blocker so that the path is cleared in time.
    j=i
    for other in range(i+6,24):
     if other//6<=i//6 or not (left[other] or remaining_people[other]):continue
     if abs(aim(s,other)-tx)<8 and other//6>j//6:j=other
    tx=aim(s,j);travel=abs(tx-x)/50
    # Finish nearby fires, with increasing priority for older strong fires.
    cost=travel+.18*left[j]+min(deadline,40)*(self.late_deadline_weight if tap_controls and limit<=2 else self.deadline_weight)+.025*(3-j//6)
    if j==self.goal:cost-=self.goal_bonus
    targets.append((cost,tx,j))
  if not targets:
   if tap_controls and water<8:
    self.refilling=True;return 0,1
   return 0,0
  _,tx,i=min(targets);self.goal=i;dx=tx-x
  j=8 if dx>1 else 4 if dx<-1 else 0;t=int(abs(dx)<=(11 if self.mode=='urgent' else 2))
  if dy and dy>145 and not s.v('invincible') and j:
   nextx=x+(2 if j==8 else -2)
   if abs(bx-nextx)<14 and abs(bx-nextx)<abs(bx-x):j=0;t=0
  if tap_controls:
   # The first short press starts a tap; the next action releases it. A
   # pending/active throw suppresses another tap until its animation ends.
   t=int(t and not s.v('press_ticks') and not s.v('throw_queued') and not s.v('throwphase'))
  if t and self.mode=='urgent':self.lock=tx
  return j,t

def run_level(level,tv,mode,max_frames=15000):
 build_hash=hashlib.sha256((ROOT/'build/FIREBALLOON.xex').read_bytes()).hexdigest()
 e=Emu(tv)
 try:
  e.step(150);e.press();assert e.val('state')==2
  e.poke('level',level-1) # ONLY gameplay-memory write: controlled level selection.
  e.step(1,t=1)
  while e.val('state')==2:e.step(1,t=1)
  e.step(1);assert e.val('state')==1
  start=Snapshot(e);bot=Bot(mode);frames=0;first_shot_frame=None;first_hit_frame=None;peak_fires=0
  while frames<max_frames:
   s=Snapshot(e)
   if s.v('state')!=1:break
   if first_shot_frame is None and s.u16('shot_count'):first_shot_frame=frames
   if first_hit_frame is None and s.u16('hits'):first_hit_frame=frames
   peak_fires=max(peak_fires,sum(v>0 for v in s.a('fires',24)))
   j,t=bot.action(s);e.step(2,j,t);frames+=2
  end=Snapshot(e);state=end.v('state')
  result={'tv':tv,'bot':mode,'level':level,'xex_sha256':build_hash,
   'controls':'tap shoot/hold refill' if 'press_ticks' in L else 'hold shoot/down refill',
   'opening_waves':start.v('wave_left'),'waves_left':end.v('wave_left'),'peak_fires':peak_fires,
   'first_shot_frame':first_shot_frame,'first_hit_frame':first_hit_frame,
   'opening_fires':sum(v>0 for v in start.a('fires',24)),'opening_strength':sum(start.a('fires',24)),'setup':'level selected in intro; joystick-only play thereafter',
   'outcome':'clear' if state==3 else 'burn' if state==8 else 'timeout' if state==4 and end.v('seconds')==0 else 'debris' if state==4 else 'probe_limit',
   'seconds_used':start.v('seconds')-end.v('seconds'),'seconds_left':end.v('seconds'),'lives_lost':start.v('lives')-end.v('lives'),
   'burns':end.v('burn_count')-start.v('burn_count'),'shots':end.u16('shot_count'),'hits':end.u16('hits'),'misses':end.u16('misses'),
   'refills':end.v('refill_count'),'remaining_fires':sum(v>0 for v in end.a('fires',24)),
   'remaining_strength':sum(end.a('fires',24)),'remaining_people':sum(end.a('residents',24)),
   'emulator_frames':frames,'grow_limit':start.v('grow_limit')}
  return result
 finally:e.close()

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--levels',default='1,5,10,15,20',help='comma-separated 1-based levels, or all')
 p.add_argument('--tv',choices=['ntsc','pal','both'],default='ntsc')
 p.add_argument('--bot',choices=['greedy','urgent','idle','hold','both'],default='both')
 p.add_argument('--output',default=str(ROOT/'build/balance_probe.json'))
 a=p.parse_args();levels=list(range(1,21)) if a.levels=='all' else [int(x) for x in a.levels.split(',')]
 out=[]
 for tv in ['ntsc','pal'] if a.tv=='both' else [a.tv]:
  for mode in ['greedy','urgent'] if a.bot=='both' else [a.bot]:
   for level in levels:
    result=run_level(level,tv,mode);out.append(result);print(json.dumps(result),flush=True)
 from pathlib import Path
 Path(a.output).write_text(json.dumps(out,indent=2)+'\n')
