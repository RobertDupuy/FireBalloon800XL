.setcpu "6502"
.macpack longbranch
.export start, state, level, lives, seconds, score, fires, residents, player_x, tick, frames, shot_y, shot_x, debris_y, debris_x, invincible, remain, saved, shot_count, hits, misses, fps, logic_count
.export fire_age, grow_limit, burn_clock, burn_row, burn_count, critical_count
.export water, refill_clock, refill_count
.export press_ticks, throw_queued, wave_left, wave_clock, wave_period, wave_cap, spawn_count
.segment "ZEROPAGE"
ptr: .res 2
src: .res 2
tmp: .res 1
tmp2: .res 1
idx: .res 1
slot: .res 1
row: .res 1
col: .res 1
work: .res 1
sptr: .res 2
renderpage: .res 1
renderoffset: .res 1
vptr: .res 2
.segment "BSS"
state: .res 1
level: .res 1
lives: .res 1
seconds: .res 1
score: .res 6
fires: .res 24
residents: .res 24
player_x: .res 1
tick: .res 1
frames: .res 1
lastframe: .res 1
fps: .res 1
accum: .res 1
logic_count: .res 2
raster: .res 1
rasterlimit: .res 1
screenmode: .res 1
pf0: .res 25
pf1: .res 25
pf2: .res 25
pf3: .res 25
bg: .res 25
fonts: .res 25
pmcolor: .res 25
ballpos: .res 50
manball: .res 50
frontpage: .res 1
frontoffset: .res 1
pending: .res 1
pendingpage: .res 1
pendingoffset: .res 1
pendingx: .res 1
pendingrock: .res 1
shot_x: .res 5
shot_y: .res 5
cooldown: .res 1
fireedge: .res 1
pauseedge: .res 1
secondtick: .res 1
spreadclock: .res 1
debrisclock: .res 1
debris_x: .res 1
debris_y: .res 1
invincible: .res 1
remain: .res 1
saved: .res 1
shot_count: .res 2
hits: .res 2
misses: .res 2
combo: .res 1
winddir: .res 1
rng: .res 1
sfx: .res 1
soundtime: .res 1
waittime: .res 1
resume_state: .res 1
flash: .res 1
windowdirty: .res 1
windowcache: .res 96
throwphase: .res 1
throw_slot: .res 1
held_y: .res 1
architecture: .res 1
win_x: .res 24
windowlo: .res 24
windowhi: .res 24
fire_age: .res 24
grow_limit: .res 1
burn_clock: .res 1
burn_row: .res 1
burn_count: .res 1
critical_count: .res 1
water: .res 1
refill_clock: .res 1
refill_count: .res 1
press_ticks: .res 1
throw_queued: .res 1
wave_left: .res 1
wave_clock: .res 1
wave_period: .res 1
wave_cap: .res 1
spawn_count: .res 1
.segment "CODE"
start:
    sei
    lda #0
    sta $d40e
    sta $d400
    sta $022f
    ldx #0
@clear:
    sta $5000,x
    sta $5100,x
    sta $5200,x
    sta $5300,x
    sta $7000,x
    sta $7100,x
    sta $7200,x
    sta $7300,x
    sta $7400,x
    sta $7500,x
    sta $7600,x
    sta $7700,x
    sta $7800,x
    sta $7900,x
    sta $7a00,x
    sta $7b00,x
    sta $7c00,x
    sta $7d00,x
    sta $7e00,x
    sta $7f00,x
    inx
    bne @clear
    ldx #0
@assets:
    lda tiledata,x
    sta $6400,x
    lda tiledata+$100,x
    sta $6500,x
    lda tiledata+$200,x
    sta $6600,x
    lda tiledata+$300,x
    sta $6700,x
    lda fontdata,x
    sta $6800,x
    lda fontdata+$100,x
    sta $6900,x
    lda fontdata+$200,x
    sta $6a00,x
    lda fontdata+$300,x
    sta $6b00,x
    inx
    bne @assets
    lda #<dli
    sta $0200
    lda #>dli
    sta $0201
    lda #<vbi
    sta $0224
    lda #>vbi
    sta $0225
    lda #$00
    sta $0230
    lda #$6c
    sta $0231
    lda #$68
    sta $02f4
    lda #$70
    sta frontpage
    sta $d407
    lda #3
    sta $d01d
    sta $d20f
    lda #1
    sta $026f
    sta $d01b
    lda #0
    sta $d008
    sta $d009
    sta $d00a
    sta $d00b
    sta $d200
    sta $d201
    sta $d203
    sta $d205
    sta $d207
    sta $d208
    sta $02c8
    ; OS VBI shadows match the top HUD before its first raster interrupt.
    lda #$02
    sta $02c6
    lda #$0e
    sta $02c5
    lda #$94
    sta $d013
    sta $02c1
    lda #$26
    sta $d014
    sta $02c2
    lda #$08
    sta $d015
    sta $02c3
    ldx #0
@bucket:
    lda bucket,x
    sta $7700+198,x
    sta $7f00+198,x
    inx
    cpx #10
    bne @bucket
    lda #120
    sta player_x
    lda #137
    sta rng
    lda #60
    ldx $d014
    cpx #15
    beq @ntsc
    lda #50
@ntsc: sta fps
    jsr title
    lda #$3e
    sta $022f
    lda #$c0
    sta $d40e
    cli
main:
    lda frames
    cmp lastframe
    beq main
    inc lastframe
    lda accum
    clc
    adc #50
    cmp fps
    bcc @skip
    sec
    sbc fps
    sta accum
    jsr logic
    jmp main
@skip: sta accum
    jmp main

vbi:
    lda screenmode
    cmp #1
    bne @nocache
    lda windowdirty
    beq @nocache
    ldx #23
@flush:
    lda windowlo,x
    sta vptr
    lda windowhi,x
    sta vptr+1
    ldy #0
    lda windowcache,x
    sta (vptr),y
    iny
    lda windowcache+24,x
    sta (vptr),y
    ldy #40
    lda windowcache+48,x
    sta (vptr),y
    iny
    lda windowcache+72,x
    sta (vptr),y
    dex
    bpl @flush
    lda #0
    sta windowdirty
@nocache:
    lda pending
    beq @none
    lda pendingpage
    sta frontpage
    sta $d407
    lda pendingoffset
    sta frontoffset
    lda pendingx
    sta $d000
    lda pendingrock
    sta $d002
    lda pendingx
    beq @nobucket
    clc
    adc #7
@nobucket:sta $d003
    lda #0
    sta pending
@none:
    inc frames
    lda #0
    sta raster
    sta $4d
    jmp $e462

dli:
    pha
    txa
    pha
    tya
    pha
    lda $d40b
    sec
    sbc #15
    lsr
    lsr
    tax
    stx raster
    cpx #19
    bne :+
    lda screenmode
    cmp #1
    beq dli_man
:   txa
    clc
    adc frontoffset
    tay
    lda ballpos,y
    tay
    lda fonts,x
    ; The old row has fetched its last glyph line. Prime the next character set
    ; before WSYNC so even ANTIC's earliest mode-2 fetch uses the correct bank.
    sta $d409
    sta $d40a
    sty $d001
    lda bg,x
    sta $d01a
    lda pf2,x
    sta $d018
    lda pf0,x
    sta $d016
    lda pf1,x
    sta $d017
    lda pf3,x
    sta $d019
    lda pmcolor,x
    sta $d012
@regular:
    inc raster
dli_restore:
    pla
    tay
    pla
    tax
    pla
    rti

dli_man:
    lda #0
    sta $d01a
    lda #$0e
    sta $d016
    lda #$06
    sta $d017
    lda #$08
    sta $d018
    lda #$2a
    sta $d015
    lda pendingx
    clc
    adc #7
    sta $d001
    lda #$46
    sta $d40a
    sta $d012
    lda #$0e
    sta $d40a
    sta $d012
    lda #$46
    sta $d40a
    sta $d012
    lda #$2a
    sta $d40a
    sta $d012
    lda #$2a
    sta $d40a
    sta $d012
    lda #$2a
    sta $d40a
    sta $d012
    lda #$2a
    sta $d40a
    sta $d012
    lda #$46
    sta $d40a
    sta $d012
    lda #$46
    sta $d40a
    sta $d012
    lda #$0e
    sta $d40a
    sta $d012
    lda #$0e
    sta $d40a
    sta $d012
    lda #$46
    sta $d40a
    sta $d012
    lda #$46
    sta $d40a
    sta $d012
    lda #$08
    sta $d015
    lda #$0e
    sta $d40a
    sta $d012
    lda #$0e
    sta $d40a
    sta $d012
    lda #$96
    sta $d40a
    sta $d012
    lda #$96
    sta $d40a
    sta $d012
    lda #$96
    sta $d40a
    sta $d012
    lda #$96
    sta $d40a
    sta $d012
    lda #$96
    sta $d40a
    sta $d012
    lda #$04
    sta $d40a
    sta $d012
    lda #$64
    sta $d409
    lda #0
    sta $d018
    sta $d01a
    lda #$0e
    sta $d017
    lda #22
    sta raster
    jmp dli_restore

; screenmode=0 text, =1 game. DL always spans 24 rows and 192 scanlines.
make_display:
    lda #$70
    sta $6c00
    sta $6c01
    lda #$f0
    sta $6c02
    lda #$c2
    ldx screenmode
    cpx #2
    bne :+
    lda #$c4
:   sta $6c03
    lda #0
    sta $6c04
    lda #$60
    sta $6c05
    ldx #1
@row:
    lda #$82
    ldy screenmode
    beq @put
    cpy #2
    beq @graphicsrow
    cpx #2
    bcc @put
@graphicsrow:
    lda #$84
@put: sta $6c05,x
    inx
    cpx #24
    bne @row
    lda screenmode
    cmp #1
    bne :+
    lda #4
    sta $6c05+19
    sta $6c05+20
:   lda #$41
    sta $6c1d
    lda #0
    sta $6c1e
    lda #$6c
    sta $6c1f
    ldx #24
@pal:
    lda #$68
    sta fonts,x
    lda #$0e
    sta pf1,x
    lda #$02
    sta pf2,x
    lda #$00
    sta bg,x
    sta ballpos,x
    lda #$ae
    sta pf3,x
    lda #$c6
    sta pf0,x
    lda #$0e
    sta pmcolor,x
    dex
    bpl @pal
    lda screenmode
    jeq @done
    cmp #2
    bne @playpalette
    ldx #24
@titlepalette:
    lda #$64
    sta fonts,x
    lda #$82
    sta bg,x
    lda #$46
    sta pf0,x
    lda #$0e
    sta pf1,x
    lda #$2e
    sta pf2,x
    lda #$96
    sta pf3,x
    dex
    bpl @titlepalette
    rts
@playpalette:
    ldx #2
@gamepal:
    lda #$64
    sta fonts,x
    ldy architecture
    lda skycolor,y
    sta bg,x
    lda #0
    sta pf1,x
    lda #$2c
    sta pf2,x
    lda #$ae
    sta pf3,x
    txa
    lsr
    lsr
    and #3
    clc
    adc wallcolor,y
    sta pf0,x
    inx
    cpx #19
    bne @gamepal
    lda #$2e
    sta pf1+5
    sta pf1+6
    sta pf1+8
    sta pf1+9
    sta pf1+11
    sta pf1+12
    sta pf1+14
    sta pf1+15
    lda #$36
    sta pf2+5
    sta pf2+8
    sta pf2+11
    sta pf2+14
    lda #$28
    sta pf2+6
    sta pf2+9
    sta pf2+12
    sta pf2+15
    lda #$0c
    sta pf2+2
    sta pf2+3
    sta pf2+4
    lda #$64
    sta fonts+19
    sta fonts+20
    sta fonts+21
    sta fonts+22
    sta fonts+23
    lda #$08
    sta pf2+19
    lda #$06
    sta pf1+19
    lda #0
    sta bg+19
    sta bg+20
    sta bg+21
    lda #$0e
    sta pf0+19
    sta pf0+20
    sta pf0+21
    lda #$38
    sta pmcolor+19
    lda #$0e
    sta pmcolor+20
    lda #$86
    sta pmcolor+21
@done: rts

clear_screen:
    lda #0
    ldx #0
@loop:
    sta $6000,x
    sta $6100,x
    sta $6200,x
    sta $6300,x
    inx
    bne @loop
    rts

; src points to zero-terminated ASCII text, ptr is destination
text:
    ldy #0
@loop:
    lda (src),y
    beq @done
    sec
    sbc #32
    sta (ptr),y
    iny
    bne @loop
@done:rts
.macro TEXT label, dest
    lda #<label
    sta src
    lda #>label
    sta src+1
    lda #<(dest)
    sta ptr
    lda #>(dest)
    sta ptr+1
    jsr text
.endmacro

textmode:
    lda #0
    sta screenmode
    sta $d000
    sta $d001
    sta $d002
    sta $d003
    sta pending
    ldx #49
@clearballs:
    sta ballpos,x
    dex
    bpl @clearballs
    jsr clear_screen
    jmp make_display

title:
    lda #0
    sta state
    jsr textmode
    lda #2
    sta screenmode
    jsr make_display
    ldx #0
@copy:
    lda titletiles,x
    sta $6400,x
    lda titletiles+$100,x
    sta $6500,x
    lda titletiles+$200,x
    sta $6600,x
    lda titletiles+$300,x
    sta $6700,x
    lda titlescreen,x
    sta $6000,x
    lda titlescreen+$100,x
    sta $6100,x
    lda titlescreen+$200,x
    sta $6200,x
    cpx #192
    bcs :+
    lda titlescreen+$300,x
    sta $6300,x
:   inx
    bne @copy
    rts

restore_tiles:
    ldx #0
@copy:
    lda tiledata,x
    sta $6400,x
    lda tiledata+$100,x
    sta $6500,x
    lda tiledata+$200,x
    sta $6600,x
    lda tiledata+$300,x
    sta $6700,x
    inx
    bne @copy
    rts

newgame:
    lda #0
    sta level
    sta saved
    sta burn_count
    ldx #5
@score:sta score,x
    dex
    bpl @score
    lda #3
    sta lives
    jmp intro

intro:
    lda #2
    sta state
    lda #25
    sta waittime
    jsr textmode
    TEXT dispatch,$6000+40*3+12
    TEXT leveltext,$6000+40*5+14
    lda level
    clc
    adc #1
    ldx #<($6000+40*5+20)
    ldy #>($6000+40*5+20)
    jsr number
    ldx level
    lda name_lo,x
    sta src
    lda name_hi,x
    sta src+1
    ldy #23
@name:lda (src),y
    sta $6000+40*7+8,y
    dey
    bpl @name
    TEXT briefbucket,$6000+40*8+3
    TEXT briefgrow,$6000+40*9+3
    TEXT brief1,$6000+40*10+3
    ldx level
    lda level_residents,x
    beq @wind
    TEXT briefrescue,$6000+40*12+3
@wind:
    ldx level
    lda level_wind,x
    beq @spread
    TEXT briefwind,$6000+40*14+3
@spread:
    ldx level
    lda level_spread,x
    beq @debris
    TEXT briefspread,$6000+40*16+3
@debris:
    ldx level
    lda level_debris,x
    beq @end
    TEXT briefdebris,$6000+40*18+3
@end:
    TEXT ready,$6000+40*21+5
    rts

beginlevel:
    jsr restore_tiles
    lda level
    ldx #0
@group:
    cmp #5
    bcc @gotgroup
    sec
    sbc #5
    inx
    bne @group
@gotgroup:
    stx architecture
    lda geometry_x_lo,x
    sta src
    lda geometry_x_hi,x
    sta src+1
    ldy #23
@copyx:
    lda (src),y
    sta win_x,y
    dey
    bpl @copyx
    lda geometry_lo_lo,x
    sta src
    lda geometry_lo_hi,x
    sta src+1
    ldy #23
@copylo:
    lda (src),y
    sta windowlo,y
    dey
    bpl @copylo
    lda geometry_hi_lo,x
    sta src
    lda geometry_hi_hi,x
    sta src+1
    ldy #23
@copyhi:
    lda (src),y
    sta windowhi,y
    dey
    bpl @copyhi
    lda #1
    sta state
    sta screenmode
    lda #0
    sta tick
    sta secondtick
    sta cooldown
    sta throwphase
    sta burn_clock
    sta refill_clock
    sta refill_count
    sta wave_clock
    sta spawn_count
    sta throw_queued
    sta critical_count
    sta spreadclock
    sta debrisclock
    sta debris_y
    sta combo
    sta hits
    sta hits+1
    sta misses
    sta misses+1
    sta shot_count
    sta shot_count+1
    ldx #23
@zero:sta fires,x
    sta residents,x
    sta fire_age,x
    dex
    bpl @zero
    ldx #4
@shots:sta shot_y,x
    dex
    bpl @shots
    lda #120
    sta player_x
    lda #100
    sta invincible
    lda #50
    sta press_ticks ; consume the button used to enter this call
    lda #8
    sta water
    ldx level
    lda level_growth,x
    sta grow_limit
    lda level_wave_count,x
    sta wave_left
    lda level_wave_period,x
    sta wave_period
    lda level_wave_cap,x
    sta wave_cap
    lda level_seconds,x
    sta seconds
    lda layout_lo,x
    sta src
    lda layout_hi,x
    sta src+1
    lda level_count,x
    sta tmp
    lda level_strength,x
    sta tmp2
    lda level_residents,x
    sta work
    ldy #0
@setfire:
    lda (src),y
    tax
    lda tmp2
    cmp #1
    beq @strengthready
    tya
    and #3
    bne :+
    lda #1
    bne @strengthready
:   cmp #3
    beq :+
    lda #2
    bne @strengthready
:   lda tmp2
@strengthready:
    sta fires,x
    iny
    cpy tmp
    bne @setfire
    lda work
    beq @draw
@setresident:
    lda (src),y
    tax
    lda #1
    sta residents,x
    iny
    dec work
    bne @setresident
@draw:
    jsr clear_screen
    jsr make_display
    ; Roof and facade, rows 4 through 18, columns 5..34.
    ldx #4
@facaderow:
    stx row
    lda screenlo,x
    sta ptr
    lda screenhi,x
    sta ptr+1
    ldy #5
    lda architecture
    cmp #1
    bne :+
    ldy #7
:   lda #1
    cpx #4
    bne @facade
    lda #2
@facade:
    sta (ptr),y
    iny
    ldx architecture
    cpx #1
    bne @wide
    cpy #33
    bne @facade
    beq @facadedone
@wide:
    cpy #35
    bne @facade
@facadedone:
    ldx row
    inx
    cpx #19
    bne @facaderow
    lda architecture
    cmp #2
    bne @nogap
    ldx #4
@gaprow:
    stx row
    lda screenlo,x
    sta ptr
    lda screenhi,x
    sta ptr+1
    ldy #18
    lda #0
@gap:
    sta (ptr),y
    iny
    cpy #23
    bne @gap
    ldx row
    inx
    cpx #17
    bne @gaprow
@nogap:
    ldx #39
    lda #7
@pave:sta $6000+19*40,x
    dex
    bpl @pave
    ldx #3
@road:
    lda #8
    sta $6000+21*40,x
    sta $6000+21*40+1,x
    sta $6000+21*40+2,x
    txa
    clc
    adc #6
    tax
    cpx #39
    bcc @road
    lda #13
    sta $6000+3*40+2
    lda #14
    sta $6000+3*40+3
    sta $6000+3*40+4
    lda #15
    sta $6000+3*40+5
    lda #9
    sta $6000+17*40+19
    lda #10
    sta $6000+17*40+20
    lda #11
    sta $6000+18*40+19
    lda #12
    sta $6000+18*40+20
    TEXT hud1,$6000
    TEXT hud2,$6000+40
    jsr windows
    jsr updatehud
    jmp sprites

logic:
    inc logic_count
    bne :+
    inc logic_count+1
:   jsr sound
    lda $d010
    beq @pressed
    lda $d01f
    and #1
    beq @pressed
    lda #0
    sta fireedge
    jmp @inputdone
@pressed:
    lda fireedge
    bne @inputdone
    lda #1
    sta fireedge
    lda waittime
    bne @inputdone
    lda state
    beq @new
    cmp #5
    beq @new
    cmp #6
    beq @new
    cmp #2
    bne @inputdone
    jsr beginlevel
    jmp @inputdone
@new:jsr newgame
@inputdone:
    lda waittime
    beq :+
    dec waittime
:   lda $d01f
    and #2
    bne @pauserelease
    lda pauseedge
    bne @pauseend
    inc pauseedge
    lda state
    cmp #1
    bne @unpause
    lda #7
    sta state
    TEXT paused,$6000+40
    jmp @pauseend
@unpause:
    cmp #7
    bne @pauseend
    lda #1
    sta state
    TEXT hud2,$6000+40
    jsr updatehud
    jmp @pauseend
@pauserelease:
    lda #0
    sta pauseedge
@pauseend:
    lda state
    cmp #1
    jeq play
    cmp #8
    jeq burn_tick
    cmp #3
    beq @cleared
    cmp #4
    beq @died
    rts
@cleared:
    lda waittime
    bne @return
    inc level
    lda level
    cmp #20
    jeq victory
    jmp intro
@died:
    lda waittime
    bne @return
    lda lives
    jeq gameover
    jmp intro
@return:rts

play:
    inc tick
    lda invincible
    beq :+
    dec invincible
:   lda cooldown
    beq :+
    dec cooldown
:   jsr button_input
    lda $d300
    and #4
    bne @right
    lda player_x
    cmp #60
    bcc @right
    dec player_x
@right:
    lda $d300
    and #8
    bne @fire
    lda player_x
    cmp #192
    bcs @fire
    inc player_x
@fire:
    lda throwphase
    beq @trigger
    dec throwphase
    lda throwphase
    cmp #6
    bne @move
    ldx throw_slot
    lda player_x
    clc
    adc #7
    sta shot_x,x
    lda #184
    sta shot_y,x
    dec water
    lda #6
    sta cooldown
    inc shot_count
    bne :+
    inc shot_count+1
:   lda #1
    jsr effect
    jmp @move
@trigger:
    lda water
    beq @move
    lda throw_queued
    beq @move
    lda cooldown
    bne @move
    ldx #0
@slot:
    lda shot_y,x
    beq @reach
    inx
    cpx #5
    bne @slot
    beq @move
@reach:
    lda #0
    sta throw_queued
    stx throw_slot
    lda #18
    sta throwphase
@move:
    jsr wind
    jsr balloons
    jsr debris
    lda state
    cmp #1
    bne @return
    jsr wave_tick
    inc secondtick
    lda secondtick
    cmp #50
    bcc @draw
    lda #0
    sta secondtick
    dec seconds
    jeq lose_life
    lda seconds
    cmp #11
    bcs @spread
    lda #4
    jsr effect
@spread:
    jsr growing
    lda state
    cmp #1
    bne @return
    jsr spreading
@draw:
    lda tick
    and #7
    bne @nodraw
    jsr windows
@nodraw:
    jsr sprites
    jsr updatehud
    lda remain
    ora wave_left
    bne @return
    jmp levelclear
@return:rts

button_input:
    lda $d010
    bne @released
    lda press_ticks
    cmp #50
    bcs @return
    inc press_ticks
    lda press_ticks
    sta refill_clock
    cmp #50
    bcc @return
    lda #0
    sta throw_queued
    lda water
    cmp #8
    bcs @return
    lda #8
    sta water
    inc refill_count
    lda #3
    jsr effect
@return:rts
@released:
    lda press_ticks
    beq @reset
    cmp #50
    bcs @reset
    lda water
    beq @reset
    lda #1
    sta throw_queued
@reset:
    lda #0
    sta press_ticks
    sta refill_clock
    rts

count_fires:
    lda #0
    ldx #23
@count:
    ldy fires,x
    beq :+
    clc
    adc #1
:   dex
    bpl @count
    rts

; Repeated outbreaks make a round a sustained emergency, rather than a single
; static arrangement. Ready waves wait for capacity; no invisible backlog is lost.
wave_tick:
    lda wave_left
    beq @return
    lda wave_clock
    cmp wave_period
    bcs @ready
    inc wave_clock
    lda wave_clock
    cmp wave_period
    bcc @return
@ready:
    jsr count_fires
    cmp wave_cap
    bcs @return
    jsr random
    and #$1f
    cmp #24
    bcc :+
    sbc #24
:   tax
    ldy #24
@search:
    lda fires,x
    ora residents,x
    beq @ignite
    inx
    cpx #24
    bcc :+
    ldx #0
:   dey
    bne @search
    rts
@ignite:
    lda #1
    sta fires,x
    lda level
    cmp #15
    bcc :+
    lda spawn_count
    and #3
    cmp #3
    bne :+
    lda #2
    sta fires,x
:   lda #0
    sta fire_age,x
    sta wave_clock
    dec wave_left
    inc spawn_count
    jsr windows
@return:rts

wind:
    ldx level
    lda level_wind,x
    cmp #3
    bne @set
    lda seconds
    and #4
    beq @east
    lda #2
    bne @set
@east:lda #1
@set:sta winddir
    rts

balloons:
    ldx #0
@loop:
    stx slot
    lda shot_y,x
    jeq @next
    sec
    sbc #2
    sta shot_y,x
    cmp #68
    bcs @drift
    lda #0
    sta shot_y,x
    sta combo
    inc misses
    jne @next
    inc misses+1
    jmp @next
@drift:
    lda tick
    and #7
    bne @collision
    lda winddir
    beq @collision
    cmp #1
    bne @west
    inc shot_x,x
    jmp @collision
@west:dec shot_x,x
@collision:
    ldy #0
@window:
    lda fires,y
    ora residents,y
    jeq @wnext
    lda shot_y,x
    sec
    sbc win_y,y
    cmp #16
    bcs @wnext
    lda shot_x,x
    sec
    sbc win_x,y
    clc
    adc #3
    cmp #12
    bcs @wnext
    sty idx
    lda #0
    sta shot_y,x
    inc hits
    bne :+
    inc hits+1
:   lda fires,y
    beq @rescue
    lda #0
    sta fire_age,y
    lda fires,y
    sec
    sbc #1
    sta fires,y
    bne @hit
    lda #10
    jsr addscore
    inc combo
    lda combo
    cmp #10
    bcc :+
    lda #9
    sta combo
:   lda combo
    jsr addscore
    lda #2
    jsr effect
    jmp @hitdone
@hit:
    lda #2
    jsr addscore
    lda #2
    jsr effect
    jmp @hitdone
@rescue:
    lda #0
    sta residents,y
    inc saved
    lda #25
    jsr addscore
    lda #3
    jsr effect
@hitdone:
    jsr windows
    jmp @next
@wnext:
    iny
    cpy #24
    jne @window
@next:
    ldx slot
    inx
    cpx #5
    jne @loop
    rts

; Score unit is 10 points; six decimal digits, saturating at 999990.
addscore:
    sta work
@again:
    ldx #4
@carry:
    inc score,x
    lda score,x
    cmp #10
    bcc @added
    lda #0
    sta score,x
    dex
    bpl @carry
    lda #9
    ldx #4
@saturate:sta score,x
    dex
    bpl @saturate
@added:
    dec work
    bne @again
    rts

random:
    lda rng
    asl
    bcc :+
    eor #$1d
:   sta rng
    rts

debris:
    lda debris_y
    bne @fall
    ldx level
    lda level_debris,x
    beq @return
    inc debrisclock
    cmp debrisclock
    bne @return
    lda #0
    sta debrisclock
    jsr random
    and #$7f
    clc
    adc #60
    sta debris_x
    ; Later falling masonry punishes standing still, with a visible fall
    ; before it reaches the street. Alternate random and aimed starting points.
    ldx level
    cpx #8
    bcc :+
    lda rng
    and #1
    bne :+
    lda player_x
    clc
    adc #2
    sta debris_x
:   lda #64
    sta debris_y
    rts
@fall:
    inc debris_y
    lda level
    cmp #8
    bcc @halfspeed
    inc debris_y
    cmp #14
    bcc @height
@halfspeed:
    lda tick
    and #1
    bne @height
    inc debris_y
@height:
    lda debris_y
    cmp #187
    bcc @return
    cmp #208
    bcs @off
    lda invincible
    bne @return
    lda debris_x
    sec
    sbc player_x
    clc
    adc #6
    cmp #15
    bcs @return
    jmp lose_life
@off:lda #0
    sta debris_y
@return:rts

spreading:
    jsr count_fires
    cmp wave_cap
    bcs @return
    ldx level
    lda level_spread,x
    beq @return
    inc spreadclock
    cmp spreadclock
    bne @return
    lda #0
    sta spreadclock
    jsr random
    and #$1f
    cmp #24
    bcc :+
    sbc #24
:   tax
    ldy #24
@seek:
    lda fires,x
    beq @advance
    stx idx
    lda next_window,x
    tax
    lda fires,x
    ora residents,x
    beq @ignite
    ldx idx
@advance:
    inx
    cpx #24
    bcc :+
    ldx #0
:   dey
    bne @seek
    rts
@ignite:
    lda #1
    sta fires,x
    lda #0
    sta fire_age,x
@return:rts

; One age tick per simulated second. A hit has already reset its fire's age
; before this runs, so a last-moment water hit wins over the burn deadline.
growing:
    lda #0
    sta critical_count
    ldx #23
@fire:
    lda fires,x
    beq @empty
    inc fire_age,x
    lda fire_age,x
    cmp grow_limit
    bcc @next
    lda #0
    sta fire_age,x
    lda fires,x
    cmp #4
    jeq burn_start
    inc fires,x
    jmp @next
@empty:
    lda #0
    sta fire_age,x
@next:
    lda fires,x
    cmp #4
    bne :+
    inc critical_count
:   dex
    bpl @fire
    lda critical_count
    beq @return
    lda #4
    jsr effect
@return:rts

; Burn-down owns its state until the animation finishes; multiple critical
; windows cannot consume more than one life for the same building.
burn_start:
    lda #8
    sta state
    dec lives
    inc burn_count
    lda #0
    sta burn_clock
    sta throwphase
    sta debris_y
    ldx #4
@shots:
    sta shot_y,x
    dex
    bpl @shots
    ldx #23
@blaze:
    lda #0
    sta residents,x
    lda #4
    sta fires,x
    dex
    bpl @blaze
    lda #4
    sta burn_row
    lda #5
    jsr effect
    jsr windows
    jsr sprites
    jsr updatehud
    TEXT burntext,$6000+40
    lda #$46
    sta pf1+1
    rts

burn_tick:
    inc tick
    inc burn_clock
    lda burn_clock
    cmp #160
    bcc @animate
    lda lives
    jeq gameover
    jmp intro
@animate:
    cmp #48
    bcs @collapse
    and #7
    bne @return
    lda burn_clock
    and #8
    beq :+
    lda #$36
    bne @flare
:   lda #$24
@flare:
    ldx #18
@wall:
    sta pf0,x
    dex
    cpx #3
    bne @wall
    jsr windows
    rts
@collapse:
    ; Charcoal palette, then erase the facade down to a low rubble pile.
    ldx #18
@charcoal:
    lda #$04
    sta pf0,x
    lda #$08
    sta pf1,x
    lda #$02
    sta pf2,x
    dex
    cpx #3
    bne @charcoal
    lda burn_clock
    and #3
    bne @return
    ldx burn_row
    cpx #19
    bcs @rubble
    lda screenlo,x
    sta ptr
    lda screenhi,x
    sta ptr+1
    ldy #5
    lda #0
@erase:
    sta (ptr),y
    iny
    cpy #35
    bne @erase
    inc burn_row
@return:rts
@rubble:
    ldx #5
@piece:
    lda #84
    sta $6000+17*40,x
    lda #85
    sta $6000+17*40+1,x
    lda #86
    sta $6000+18*40,x
    lda #87
    sta $6000+18*40+1,x
    inx
    inx
    cpx #35
    bne @piece
    rts

lose_life:
    dec lives
    lda #4
    sta state
    lda #100
    sta waittime
    lda #5
    jsr effect
    lda #0
    sta $d000
    jsr updatehud
    TEXT lost,$6000+40
    rts

levelclear:
    lda #3
    sta state
    lda #110
    sta waittime
    lda seconds
    beq :+
    jsr addscore
:   lda #3
    jsr effect
    jsr updatehud
    TEXT cleartext,$6000+40
    rts

gameover:
    lda #5
    sta state
    jsr textmode
    TEXT overtext,$6000+40*6+14
    TEXT finalscore,$6000+40*10+10
    jsr endscore
    TEXT againtext,$6000+40*18+7
    rts
victory:
    lda #6
    sta state
    jsr textmode
    TEXT wintext1,$6000+40*4+8
    TEXT wintext2,$6000+40*7+5
    TEXT finalscore,$6000+40*10+10
    jsr endscore
    TEXT wintext3,$6000+40*13+6
    TEXT wintext4,$6000+40*15+8
    TEXT againtext,$6000+40*20+7
    rts
endscore:
    ldx #5
@loop:lda score,x
    clc
    adc #16
    sta $6000+40*10+23,x
    dex
    bpl @loop
    rts

windows:
    lda #0
    sta windowdirty
    ldx #0
@loop:
    stx idx
    lda windowlo,x
    sta ptr
    lda windowhi,x
    sta ptr+1
    lda fires,x
    beq @notfire
    lda tick
    lsr
    lsr
    lsr
    clc
    adc idx
    and #3
    asl
    asl
    clc
    adc #16
    ; Fire base tile index, all four tiles contiguous.
    sta tmp
    lda fires,x
    sec
    sbc #1
    asl
    asl
    asl
    asl
    clc
    adc tmp
    sta tmp
    jmp @tiles
@notfire:
    lda residents,x
    beq @empty
    lda #208
    sta tmp
    jmp @tiles
@empty:
    lda #131
    sta tmp
@tiles:
    ldx idx
    lda tmp
    sta windowcache,x
    clc
    adc #1
    sta windowcache+24,x
    clc
    adc #1
    sta windowcache+48,x
    clc
    adc #1
    sta windowcache+72,x
    inx
    cpx #24
    bne @loop
    lda #1
    sta windowdirty
    rts

sprites:
    lda frontpage
    eor #8
    sta pendingpage
    clc
    adc #4
    sta renderpage
    sta sptr+1
    lda #0
    sta sptr
    lda frontoffset
    eor #25
    sta renderoffset
    sta pendingoffset
    lda #0
    inc sptr+1
    ldy #0
@clear1:
    sta (sptr),y
    iny
    bne @clear1
    inc sptr+1
    ldy #0
@clear2:
    sta (sptr),y
    iny
    bne @clear2
    ldx renderoffset
    ldy #25
@reset:
    sta ballpos,x
    inx
    dey
    bne @reset
    lda player_x
    ldx invincible
    beq @visible
    lda tick
    and #4
    beq @hidden
    lda player_x
    bne @visible
@hidden:lda #0
@visible:sta pendingx
    lda renderpage
    sta sptr+1
    ldx #0
    lda refill_clock
    beq :+
    ldx #24
    jmp @posechosen
:   lda throwphase
    beq @posechosen
    ldx #24
    cmp #13
    bcs @posechosen
    ldx #48
    cmp #7
    bcs @posechosen
    ldx #72
@posechosen:
    ldy #184
@shape:
    lda person,x
    sta (sptr),y
    iny
    inx
    cpy #208
    bne @shape
    inc sptr+1
    ldx #0
@balloon:
    stx slot
    lda shot_y,x
    beq @next
    tay
    ldx #0
@bits:
    lda balloon,x
    sta (sptr),y
    iny
    inx
    cpx #6
    bne @bits
    ldx slot
    lda shot_y,x
    sec
    sbc #32
    lsr
    lsr
    lsr
    clc
    adc renderoffset
    tay
    lda shot_x,x
    sta ballpos,y
    lda shot_y,x
    and #7
    cmp #3
    bcc @next
    lda shot_x,x
    sta ballpos+1,y
@next:
    ldx slot
    inx
    cpx #5
    bne @balloon
    ; The retrieved balloon rises visibly from the bucket to the throwing hand.
    lda #0
    sta held_y
    lda throwphase
    cmp #7
    bcc @noheld
    cmp #13
    bcs @noheld
    asl
    clc
    adc #172
    sta held_y
    tay
    ldx #0
@heldbits:
    lda balloon,x
    sta (sptr),y
    iny
    inx
    cpx #6
    bne @heldbits
    lda held_y
    sec
    sbc #32
    lsr
    lsr
    lsr
    clc
    adc renderoffset
    tay
    lda player_x
    clc
    adc #7
    sta ballpos,y
    lda held_y
    and #7
    cmp #3
    bcc @noheld
    lda player_x
    clc
    adc #7
    sta ballpos+1,y
@noheld:
    inc sptr+1
    lda #0
    sta pendingrock
    lda debris_y
    beq @done
    tay
    ldx #5
@rock:
    lda rock,x
    sta (sptr),y
    iny
    dex
    bpl @rock
    lda debris_x
    sta pendingrock
@done:
    inc sptr+1
    ldy #176
    lda #0
@clearbucket:
    sta (sptr),y
    iny
    cpy #208
    bne @clearbucket
    ldy #198
    ldx #0
@drawbucket:
    lda bucket,x
    sta (sptr),y
    iny
    inx
    cpx #10
    bne @drawbucket
    lda throwphase
    beq @ready
    lda held_y
    bne @hand
    lda #191
    ldx throwphase
    cpx #13
    bcs @hand
    lda #179
@hand:
    clc
    adc #5
    tay
    lda #$c0
    sta (sptr),y
    iny
    sta (sptr),y
@ready:
    ldx renderoffset
    lda ballpos+19,x
    ldy #0
@manrow1:
    sta manball,x
    inx
    iny
    cpy #8
    bne @manrow1
    ldx renderoffset
    lda ballpos+20,x
    ldx renderoffset
    inx
    inx
    inx
    inx
    inx
    inx
    inx
    inx
@manrow2:
    sta manball,x
    inx
    iny
    cpy #16
    bne @manrow2
    ldx renderoffset
    lda ballpos+21,x
    sta tmp
    txa
    clc
    adc #16
    tax
    lda tmp
@manrow3:
    sta manball,x
    inx
    iny
    cpy #24
    bne @manrow3
    lda #1
    sta pending
    rts

updatehud:
    ldx #5
@score:lda score,x
    clc
    adc #16
    sta $6000+6,x
    dex
    bpl @score
    lda seconds
    ldx #<($6000+19)
    ldy #>($6000+19)
    jsr number
    lda lives
    clc
    adc #16
    sta $6000+31
    lda level
    clc
    adc #1
    ldx #<($6000+37)
    ldy #>($6000+37)
    jsr number
    lda #0
    sta remain
    sta tmp2
    sta critical_count
    ldx #23
@count:
    lda fires,x
    beq :+
    inc remain
    cmp #4
    bne :+
    inc critical_count
:   lda residents,x
    beq :+
    inc tmp2
:   dex
    bpl @count
    lda remain
    ldx #<($6000+40+1)
    ldy #>($6000+40+1)
    jsr number
    lda tmp2
    clc
    adc remain
    sta remain
    lda tmp2
    clc
    adc #16
    sta $6000+40+7
    lda water
    sta tmp2
    lda #87 ; W for the water gauge at rest
    ldx refill_clock
    beq @bar
    lda refill_segments,x
    sta tmp2
    lda #82 ; R while charging
@bar:
    sec
    sbc #32
    sta $6000+40+9
    ldx #0
@segment:
    lda #63 ; custom empty meter glyph
    cpx tmp2
    bcs :+
    lda #62 ; custom filled meter glyph
:   sta $6000+40+11,x
    inx
    cpx #8
    bne @segment
    lda winddir
    clc
    adc #13
    ldx winddir
    beq @wind
    lda #30
    cpx #1
    beq @wind
    lda #28
@wind:sta $6000+40+26
    lda wave_left
    ldx #<($6000+40+33)
    ldy #>($6000+40+33)
    jsr number
    lda #$0e
    ldx critical_count
    beq @normal
    lda tick
    and #16
    beq :+
    lda #$46
    bne @normal
:   lda #$0e
@normal:
    sta pf1+1
    rts

; A unsigned byte to three digits at Y:X. Clobbers tmp only.
number:
    stx ptr
    sty ptr+1
    ldy #0
    ldx #16
@hundred:
    cmp #100
    bcc @h
    sec
    sbc #100
    inx
    bne @hundred
@h:sta tmp
    txa
    sta (ptr),y
    iny
    lda tmp
    ldx #16
@ten:
    cmp #10
    bcc @t
    sec
    sbc #10
    inx
    bne @ten
@t:sta tmp
    txa
    sta (ptr),y
    iny
    lda tmp
    clc
    adc #16
    sta (ptr),y
    rts

effect:
    sta sfx
    lda #12
    sta soundtime
    rts
sound:
    lda soundtime
    beq @off
    dec soundtime
    ldx sfx
    lda tone,x
    sec
    sbc soundtime
    sta $d200
    lda timbre,x
    sta $d201
    rts
@off:lda #0
    sta $d201
    rts
.segment "RODATA"
handcolors: .byte $2a,$2a,$2a,$2a,$2a,$2a,$2a,$2a,$2a,$2a,$2a,$2a,$2a,$2a,$08,$08,$08,$08,$08,$08,$08,$08,$08,$08
costume: .byte $46,$0e,$46,$46,$2a,$2a,$2a,$2a,$46,$46,$0e,$0e,$46,$46,$0e,$0e,$96,$96,$96,$96,$96,$96,$04,$04
; Idle, reach into bucket, lift, and overhead throw/follow-through.
person:
.byte $18,$3c,$7e,$3c,$3c,$3c,$24,$18,$7e,$7e,$bd,$bd,$3c,$3c,$3c,$3c,$66,$66,$66,$66,$66,$66,$e7,$e7
.byte $18,$3c,$7e,$3c,$3c,$3c,$24,$18,$7c,$7e,$bf,$bd,$3f,$3f,$3d,$39,$66,$66,$66,$66,$66,$66,$e7,$e7
.byte $18,$3c,$7e,$3d,$3f,$3f,$27,$1b,$7f,$7e,$bc,$bc,$3c,$3c,$3c,$3c,$66,$66,$66,$66,$66,$66,$e7,$e7
.byte $19,$3d,$7f,$3f,$3f,$3d,$25,$19,$7f,$7e,$bc,$bc,$3c,$3c,$3c,$3c,$66,$66,$66,$66,$66,$66,$e7,$e7
balloon: .byte $18,$3c,$7e,$7e,$3c,$18
bucket: .byte $3c,$42,$42,$7e,$7e,$7e,$7e,$7e,$7e,$3c
rock: .byte $18,$7c,$fe,$ff,$7e,$3c
tone: .byte 0,45,100,65,28,180
timbre: .byte 0,$a6,$86,$a8,$a6,$88
screenlo: .repeat 24,I
.byte <($6000+40*I)
.endrepeat
screenhi: .repeat 24,I
.byte >($6000+40*I)
.endrepeat
win_y: .repeat 24,I
.byte 72+(I/6)*24
.endrepeat
next_window: .repeat 24,I
.byte (I/6)*6+((I+1) .mod 6)
.endrepeat
.include "levels.inc"
.include "geometry.inc"
refill_segments: .repeat 51,I
.byte (I*8)/50
.endrepeat
wallcolor: .byte $c4,$b4,$24,$04
skycolor: .byte $98,$98,$88,$82
title1:.asciiz "F I R E B A L L O O N"
title2:.asciiz "20 CALLS. ONE NEIGHBORHOOD."
title3:.asciiz "MOVE LEFT / RIGHT WITH JOYSTICK"
title4:.asciiz "TAP FIRE: THROW. HOLD FIRE: REFILL"
title5:.asciiz "CLEAR EVERY FIRE BEFORE TIME ENDS"
title6:.asciiz "AIM AT PEOPLE TO RESCUE THEM"
title7:.asciiz "WATCH THE REFILL BAR. KEEP MOVING."
title8:.asciiz "PRESS FIRE OR START"
title9:.asciiz "CREATED BY MARK2006"
dispatch:.asciiz "FIRE DISPATCH"
leveltext:.asciiz "CALL"
briefbucket:.asciiz "TAP FIRE: THROW. HOLD FIRE: REFILL"
briefgrow:.asciiz "FIRES GROW FAST. COOL THE BIG ONES!"
brief1:.asciiz "EXTINGUISH ALL BURNING WINDOWS."
briefrescue:.asciiz "PEOPLE AT WINDOWS: HIT TO RESCUE."
briefwind:.asciiz "WIND: ADJUST YOUR THROW POSITION."
briefspread:.asciiz "FIRE SPREADS TO NEIGHBOR WINDOWS."
briefdebris:.asciiz "FALLING BRICKS: KEEP MOVING."
ready:.asciiz "PRESS FIRE WHEN YOU ARE READY"
hud1:.asciiz "SCORE 000000  TIME 000   LIVES 0  LV 000"
hud2:.asciiz "F000 P 0 W --------  WIND - NEXT 000    "
paused:.asciiz "PAUSED - PRESS SELECT TO CONTINUE        "
burntext:.asciiz "BUILDING LOST - FIRE OUT OF CONTROL      "
lost:.asciiz "CALL FAILED - TRY AGAIN                  "
cleartext:.asciiz "BUILDING SAFE! TIME BONUS AWARDED        "
overtext:.asciiz "GAME OVER"
finalscore:.asciiz "FINAL SCORE:"
againtext:.asciiz "PRESS FIRE FOR A NEW GAME"
wintext1:.asciiz "THE BLOCK IS SAFE!"
wintext2:.asciiz "ALL 20 EMERGENCY CALLS COMPLETE"
wintext3:.asciiz "THE NEIGHBORHOOD THANKS YOU."
wintext4:.asciiz "A HERO WITH A BUCKET."
.segment "ASSETS"
tiledata:.incbin "tiles.bin"
fontdata:.incbin "font.bin"
titletiles:.incbin "title_tiles.bin"
titlescreen:.incbin "title_screen.bin"
